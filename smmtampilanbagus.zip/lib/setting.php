<?php

//Pengaturan Website
$config['web'] = array(
	'url' => 'https://nasionalpedia.my.id/' // ex: http://domain.com/
);
?>
