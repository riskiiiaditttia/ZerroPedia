<?php
require '../mainconfig.php';
require '../lib/header.php';
?>
						<div class="row">
							<div class="col-lg-12">
								<div class="card-box">
									<h4 class="m-t-0 m-b-30 header-title"><i class="fa fa-file"></i> Apa Yang Baru?</h4>
                                    <ul>
                                        <li>Update System, Inshaallah Terjaga</li>
                                        <li>Pemantapan dalam design website</li>
                                        <li><b>Pengguna:</b> Grafik Pesanan/Bulan.</li>
                                        <li><b>Admin:</b> Data Profit/Grafik Deposit, Layanan, Pesanan.</li>
                                        <li>Kini sudah tersedia Deposit Otomatis, All Operator untuk Pulsa. Dan BCA/BNI untuk Bank.</li>
                                        <li><b>#Catatan :</b> Jasa yang kami sediakan sudah termasuk full support & update, jika apabila anda memiliki kendala atau memerlukan bantuan, anda dapat menghubungi kami melalui kontak yang sudah ada.</li>
                                    </ul>
								</div>
							</div>
						</div>
<?php
require '../lib/footer.php';
?>